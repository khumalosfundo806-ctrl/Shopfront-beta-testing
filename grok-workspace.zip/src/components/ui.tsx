import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";
import { invoiceTone, stageTone, type Tone } from "@/lib/studio-shared";

const tones: Record<Tone, string> = {
  navy: "bg-navy text-paper",
  gold: "bg-gold text-navy",
  soft: "bg-gold-soft text-navy",
  line: "bg-line text-navy",
};

export function Badge({ children, tone = "line" }: { children: ReactNode; tone?: Tone }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-1 text-sm font-medium", tones[tone])}>
      {children}
    </span>
  );
}

export function StageBadge({ stage }: { stage: string }) {
  const tone = stageTone(stage);
  return <Badge tone={tone.tone}>{tone.label}</Badge>;
}

export function InvoiceBadge({ status, dueOn }: { status: string; dueOn: string | null }) {
  const tone = invoiceTone(status, dueOn);
  return <Badge tone={tone.tone}>{tone.label}</Badge>;
}

const buttonStyles = {
  primary: "bg-navy text-paper hover:bg-navy-soft",
  gold: "bg-gold text-navy hover:bg-gold-soft",
  ghost: "bg-transparent text-paper hover:bg-white/10",
  line: "bg-card text-navy shadow-card hover:bg-paper",
  whatsapp: "bg-whatsapp text-paper hover:bg-navy",
} as const;

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof buttonStyles }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        buttonStyles[variant],
        className,
      )}
      {...props}
    />
  );
}

export const fieldClass =
  "min-h-11 w-full rounded-xl border border-line bg-card px-3 text-base text-ink outline-none placeholder:text-muted focus:border-navy";

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      {children}
      {hint ? <span className="mt-1.5 block text-sm text-muted">{hint}</span> : null}
    </label>
  );
}

export function Card({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return <section className={cn("rounded-2xl bg-card p-4 shadow-card sm:p-5", className)}>{children}</section>;
}

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <Card className="text-center">
      <h2 className="font-display text-xl font-semibold">{title}</h2>
      <p className="mx-auto mt-2 max-w-md text-muted">{body}</p>
      {action ? <div className="mt-4">{action}</div> : null}
    </Card>
  );
}
