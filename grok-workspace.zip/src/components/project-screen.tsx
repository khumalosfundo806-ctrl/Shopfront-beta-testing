import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import {
  addAsset,
  addComment,
  createInvoice,
  deleteAsset,
  loadProject,
  logTime,
  startTimer,
  toggleCheck,
  updateProject,
  updateStage,
} from "@/lib/studio.functions";
import { toast } from "sonner";
import { StageStepper } from "@/components/bits";
import { useStudio } from "@/components/shell";
import { Button, Card, Field, InvoiceBadge, fieldClass } from "@/components/ui";
import {
  daysOnProject,
  formatDay,
  formatMinutes,
  formatWhen,
  formatZar,
  packageMeta,
  randsToCents,
  todayKey,
  waDigits,
  type Asset,
} from "@/lib/studio-shared";

function youtubeId(url: string) {
  try {
    const parsed = new URL(url);
    if (parsed.hostname === "youtu.be") return parsed.pathname.slice(1, 20);
    if (parsed.hostname.includes("youtube.com")) return parsed.searchParams.get("v");
  } catch {
    return null;
  }
  return null;
}

async function fileToDataUrl(file: File) {
  if (!file.type.startsWith("image/")) throw new Error("Choose a photo.");
  if (file.size > 450_000) throw new Error("Use a photo under 450KB, or paste a link.");
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.readAsDataURL(file);
  });
}

export function ProjectScreen({ projectId }: { projectId: string }) {
  const { role, previewClient, run } = useStudio();
  const query = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => loadProject({ data: projectId }),
  });
  const [tab, setTab] = useState<"brief" | "money" | "time" | "thread">("brief");

  if (query.isPending) return <Card><p className="text-muted">Opening the project…</p></Card>;
  if (query.isError || !query.data) {
    return <Card><p>That project is not on your desk.</p></Card>;
  }
  const detail = query.data;
  if (role === "client" && previewClient && detail.project.clientId !== previewClient.id) {
    return <Card><p>Switch back to the studio to open another customer.</p></Card>;
  }
  const staff = role !== "client";
  const project = detail.project;
  const pack = packageMeta(project.packageId);
  const days = daysOnProject(project.createdAt, project.deliveredAt);
  const digits = waDigits(detail.client.whatsapp || detail.client.phone);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-gold-deep">{pack.name}</p>
          <h1 className="mt-1 font-display text-3xl font-semibold">{project.clientName}</h1>
          <p className="mt-2 max-w-2xl text-muted">{project.summary}</p>
        </div>
        {digits && staff ? (
          <a href={`https://wa.me/${digits}`} target="_blank" rel="noreferrer">
            <Button variant="whatsapp">WhatsApp {detail.client.contactName.split(" ")[0]}</Button>
          </a>
        ) : null}
      </div>
      <Card>
        <StageStepper
          stage={project.stage}
          onPick={
            staff
              ? (stage) => {
                  void run(() => updateStage({ data: { projectId, stage } }));
                }
              : undefined
          }
        />
        <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Metric label="Quote" value={project.quoteCents ? formatZar(project.quoteCents) : "To quote"} />
          <Metric label="Paid" value={formatZar(project.paidCents)} />
          <Metric label="Balance" value={formatZar(project.balanceCents)} />
          <Metric label={project.deliveredAt ? "Days to deliver" : "Days open"} value={String(days)} />
        </dl>
        <p className="mt-3 text-sm text-muted">
          {formatMinutes(project.minutes)} logged
          {project.leadName ? ` · Lead ${project.leadName}` : ""}
          {project.dueOn ? ` · Due ${formatDay(project.dueOn)}` : ""}
        </p>
      </Card>
      {staff ? <JobEditor projectId={projectId} summary={project.summary} quoteCents={project.quoteCents} leadName={project.leadName} dueOn={project.dueOn} /> : null}
      <div className="flex gap-2 overflow-x-auto">
        {(
          [
            ["brief", "Brief"],
            ["money", "Money"],
            ...(staff ? [["time", "Time"] as const] : []),
            ["thread", "Notes"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`min-h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${tab === id ? "bg-navy text-paper" : "bg-card text-navy shadow-card"}`}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>
      {tab === "brief" ? <BriefTab projectId={projectId} checklist={detail.checklist} assets={detail.assets} staff={staff} /> : null}
      {tab === "money" ? (
        <MoneyTab
          projectId={projectId}
          invoices={detail.invoices}
          suggestedCents={project.invoicedCents > 0 ? project.balanceCents : project.quoteCents}
          title={project.title}
          staff={staff}
        />
      ) : null}
      {tab === "time" && staff ? (
        <TimeTab projectId={projectId} entries={detail.entries} minutes={project.minutes} />
      ) : null}
      {tab === "thread" ? <ThreadTab projectId={projectId} comments={detail.comments} staff={staff} /> : null}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-paper px-3 py-2">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="font-display text-xl font-semibold tabular-nums">{value}</dd>
    </div>
  );
}

function JobEditor({
  projectId,
  summary,
  quoteCents,
  leadName,
  dueOn,
}: {
  projectId: string;
  summary: string;
  quoteCents: number;
  leadName: string;
  dueOn: string | null;
}) {
  const { run, ws } = useStudio();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState(summary);
  const [quote, setQuote] = useState(quoteCents ? String(quoteCents / 100) : "");
  const [lead, setLead] = useState(leadName);
  const [due, setDue] = useState(dueOn ?? "");
  if (!open) {
    return (
      <button type="button" className="text-sm font-semibold text-gold-deep" onClick={() => setOpen(true)}>
        Edit quote, lead and due date
      </button>
    );
  }
  return (
    <Card>
      <form
        className="grid gap-3 sm:grid-cols-2"
        onSubmit={(event) => {
          event.preventDefault();
          const cents = quote.trim() ? randsToCents(quote) : 0;
          if (quote.trim() && cents == null) {
            toast.error("Enter the quote in rands.");
            return;
          }
          void run(() =>
            updateProject({
              data: { projectId, summary: text, quoteCents: cents ?? 0, leadName: lead, dueOn: due },
            }),
          ).then((result) => {
            if (result.ok) setOpen(false);
          });
        }}
      >
        <Field label="Summary">
          <textarea className={`${fieldClass} min-h-24 py-2`} value={text} onChange={(event) => setText(event.target.value)} />
        </Field>
        <div className="space-y-3">
          <Field label="Quote in rands">
            <input className={fieldClass} inputMode="decimal" value={quote} onChange={(event) => setQuote(event.target.value)} />
          </Field>
          <Field label="Lead">
            <input className={fieldClass} value={lead} onChange={(event) => setLead(event.target.value)} list="team-names" />
            <datalist id="team-names">
              {ws.team.map((member) => (
                <option key={member.id} value={member.name} />
              ))}
            </datalist>
          </Field>
          <Field label="Due">
            <input className={fieldClass} type="date" value={due} onChange={(event) => setDue(event.target.value)} />
          </Field>
        </div>
        <div className="flex gap-2 sm:col-span-2">
          <Button type="submit">Save job</Button>
          <Button variant="line" onClick={() => setOpen(false)}>
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  );
}

function BriefTab({
  projectId,
  checklist,
  assets,
  staff,
}: {
  projectId: string;
  checklist: { id: string; label: string; done: boolean }[];
  assets: Asset[];
  staff: boolean;
}) {
  const { run } = useStudio();
  const done = checklist.filter((item) => item.done).length;
  return (
    <div className="grid gap-4 lg:grid-cols-5">
      <Card className="lg:col-span-2">
        <h2 className="font-display text-xl font-semibold">Still needed</h2>
        <p className="mt-1 text-sm text-muted">
          {done} of {checklist.length} in.
        </p>
        <ul className="mt-3 space-y-2">
          {checklist.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                className="flex min-h-11 w-full items-center gap-3 rounded-xl bg-paper px-3 text-left"
                onClick={() => void run(() => toggleCheck({ data: { itemId: item.id, done: !item.done } }))}
              >
                <span className={`grid size-5 place-items-center rounded-md ${item.done ? "bg-navy text-paper" : "bg-card shadow-card"}`} aria-hidden>
                  {item.done ? <Check className="size-3.5" /> : null}
                </span>
                <span className={item.done ? "text-muted" : "font-medium"}>{item.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </Card>
      <div className="space-y-4 lg:col-span-3">
        <AssetComposer projectId={projectId} />
        {assets.length === 0 ? <Card><p className="text-muted">No photos, words or colours yet.</p></Card> : null}
        <div className="grid gap-3 sm:grid-cols-2">
          {assets.map((asset) => (
            <AssetCard key={asset.id} asset={asset} staff={staff} onDelete={() => void run(() => deleteAsset({ data: { assetId: asset.id } }))} />
          ))}
        </div>
      </div>
    </div>
  );
}

function AssetCard({ asset, onDelete, staff }: { asset: Asset; onDelete: () => void; staff: boolean }) {
  const video = asset.kind === "video" ? youtubeId(asset.url) : null;
  return (
    <article className="overflow-hidden rounded-2xl bg-card shadow-card">
      {asset.kind === "color" ? <div className="h-20" style={{ background: asset.color }} /> : null}
      {asset.kind === "image" && asset.url ? (
        <img src={asset.url} alt={asset.title} className="h-40 w-full object-cover" />
      ) : null}
      {video ? (
        <iframe
          className="aspect-video w-full"
          src={`https://www.youtube.com/embed/${video}`}
          title={asset.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        />
      ) : null}
      <div className="p-4">
        <p className="text-sm font-medium text-gold-deep">
          {asset.kind === "copy" ? "Words" : asset.kind === "color" ? "Colour" : asset.kind === "video" ? "Video" : "Image"}
        </p>
        <h3 className="font-display text-lg font-semibold">{asset.title}</h3>
        {asset.kind === "color" ? <p className="mt-1 text-sm tabular-nums">{asset.color}</p> : null}
        {asset.body ? <p className="mt-2 whitespace-pre-wrap text-sm">{asset.body}</p> : null}
        {asset.url && asset.kind !== "image" && !video ? (
          <a href={asset.url} className="mt-2 inline-block text-sm font-semibold text-gold-deep" target="_blank" rel="noreferrer">
            Open link
          </a>
        ) : null}
        {staff ? (
          <button type="button" className="mt-3 text-sm text-muted" onClick={onDelete}>
            Remove
          </button>
        ) : null}
      </div>
    </article>
  );
}

function AssetComposer({ projectId }: { projectId: string }) {
  const { run } = useStudio();
  const [kind, setKind] = useState<"copy" | "color" | "image" | "video">("copy");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [url, setUrl] = useState("");
  const [color, setColor] = useState("#10233f");
  return (
    <Card>
      <h2 className="font-display text-xl font-semibold">Add to the brief</h2>
      <div className="mt-3 flex flex-wrap gap-2">
        {(
          [
            ["copy", "Words"],
            ["color", "Colour"],
            ["image", "Image"],
            ["video", "Video"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`min-h-11 rounded-full px-4 text-sm font-semibold ${kind === id ? "bg-gold text-navy" : "bg-paper text-navy"}`}
            onClick={() => setKind(id)}
          >
            {label}
          </button>
        ))}
      </div>
      <form
        className="mt-4 space-y-3"
        onSubmit={(event) => {
          event.preventDefault();
          void run(() =>
            addAsset({
              data: { projectId, kind, title, body, url, color: kind === "color" ? color : "" },
            }),
          ).then((result) => {
            if (result.ok) {
              setTitle("");
              setBody("");
              setUrl("");
            }
          });
        }}
      >
        <Field label="Title">
          <input className={fieldClass} value={title} onChange={(event) => setTitle(event.target.value)} placeholder={kind === "copy" ? "Homepage" : "Logo"} />
        </Field>
        {kind === "copy" || kind === "video" || kind === "image" ? (
          <Field label={kind === "copy" ? "Words" : "Note"}>
            <textarea className={`${fieldClass} min-h-24 py-2`} value={body} onChange={(event) => setBody(event.target.value)} />
          </Field>
        ) : null}
        {kind === "color" ? (
          <Field label="Colour">
            <input className="h-11 w-full" type="color" value={color} onChange={(event) => setColor(event.target.value)} />
          </Field>
        ) : null}
        {kind === "image" || kind === "video" ? (
          <Field label="Link" hint={kind === "image" ? "Or choose a photo under 450KB." : "YouTube or a Drive link."}>
            <input className={fieldClass} value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://" />
          </Field>
        ) : null}
        {kind === "image" ? (
          <Field label="Photo">
            <input
              className="block w-full text-sm"
              type="file"
              accept="image/*"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                void fileToDataUrl(file)
                  .then((dataUrl) => setUrl(dataUrl))
                  .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "Could not read that photo."));
              }}
            />
          </Field>
        ) : null}
        <Button type="submit">Add to brief</Button>
      </form>
    </Card>
  );
}

function MoneyTab({
  projectId,
  invoices,
  suggestedCents,
  title,
  staff,
}: {
  projectId: string;
  invoices: { id: string; number: string; status: string; dueOn: string | null; balanceCents: number; totalCents: number; paidCents: number }[];
  suggestedCents: number;
  title: string;
  staff: boolean;
}) {
  const { run } = useStudio();
  const [description, setDescription] = useState(title);
  const [amount, setAmount] = useState(suggestedCents > 0 ? String(suggestedCents / 100) : "");
  const [dueOn, setDueOn] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() + 7);
    return todayKey(date);
  });
  const [notes, setNotes] = useState("50% deposit to begin. Balance when the site is ready.");
  return (
    <div className="space-y-4">
      {invoices.length === 0 ? <Card><p className="text-muted">No invoice yet.</p></Card> : null}
      <div className="grid gap-3">
        {invoices.map((invoice) => (
          <Link key={invoice.id} to="/app/invoices/$invoiceId" params={{ invoiceId: invoice.id }} className="block">
            <Card>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-display text-lg font-semibold">{invoice.number}</p>
                  <p className="text-sm text-muted tabular-nums">
                    {formatZar(invoice.totalCents)} · paid {formatZar(invoice.paidCents)}
                    {invoice.dueOn ? ` · due ${formatDay(invoice.dueOn)}` : ""}
                  </p>
                </div>
                <InvoiceBadge status={invoice.status} dueOn={invoice.dueOn} />
              </div>
            </Card>
          </Link>
        ))}
      </div>
      {staff ? (
        <Card>
          <h2 className="font-display text-xl font-semibold">New invoice</h2>
          <form
            className="mt-3 space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              const unitCents = randsToCents(amount);
              if (!unitCents) {
                toast.error("Enter an amount in rands.");
                return;
              }
              void run(() =>
                createInvoice({
                  data: {
                    projectId,
                    notes,
                    dueOn,
                    lines: [{ description, unitCents }],
                  },
                }),
              ).then((result) => {
                if (result.ok) toast.success("Draft invoice ready to send.");
              });
            }}
          >
            <Field label="Line">
              <input className={fieldClass} value={description} onChange={(event) => setDescription(event.target.value)} />
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Amount in rands">
                <input className={fieldClass} inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} />
              </Field>
              <Field label="Due">
                <input className={fieldClass} type="date" value={dueOn} onChange={(event) => setDueOn(event.target.value)} />
              </Field>
            </div>
            <Field label="Note on the invoice">
              <textarea className={`${fieldClass} min-h-20 py-2`} value={notes} onChange={(event) => setNotes(event.target.value)} />
            </Field>
            <Button type="submit">Create draft</Button>
          </form>
        </Card>
      ) : null}
    </div>
  );
}

function TimeTab({
  projectId,
  entries,
  minutes,
}: {
  projectId: string;
  entries: { id: string; memberName: string; minutes: number; note: string; workedOn: string }[];
  minutes: number;
}) {
  const { run, ws } = useStudio();
  const [hours, setHours] = useState("1");
  const [mins, setMins] = useState("0");
  const [note, setNote] = useState("");
  const [workedOn, setWorkedOn] = useState(todayKey());
  const [memberName, setMemberName] = useState(ws.me.name);
  return (
    <div className="grid gap-4 lg:grid-cols-5">
      <Card className="lg:col-span-2">
        <h2 className="font-display text-xl font-semibold">{formatMinutes(minutes)} on this job</h2>
        <form
          className="mt-3 space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            const total = Math.round(Number(hours || 0) * 60 + Number(mins || 0));
            void run(() => logTime({ data: { projectId, minutes: total, note, workedOn, memberName } })).then((result) => {
              if (result.ok) setNote("");
            });
          }}
        >
          <div className="grid grid-cols-2 gap-3">
            <Field label="Hours">
              <input className={fieldClass} inputMode="numeric" value={hours} onChange={(event) => setHours(event.target.value)} />
            </Field>
            <Field label="Minutes">
              <input className={fieldClass} inputMode="numeric" value={mins} onChange={(event) => setMins(event.target.value)} />
            </Field>
          </div>
          <Field label="Who">
            <input className={fieldClass} value={memberName} onChange={(event) => setMemberName(event.target.value)} />
          </Field>
          <Field label="Day">
            <input className={fieldClass} type="date" value={workedOn} onChange={(event) => setWorkedOn(event.target.value)} />
          </Field>
          <Field label="Note">
            <input className={fieldClass} value={note} onChange={(event) => setNote(event.target.value)} />
          </Field>
          <div className="flex flex-wrap gap-2">
            <Button type="submit">Log time</Button>
            <Button variant="line" onClick={() => void run(() => startTimer({ data: { projectId } }))}>
              Start timer
            </Button>
          </div>
        </form>
      </Card>
      <Card className="lg:col-span-3">
        <h2 className="font-display text-xl font-semibold">Log</h2>
        <ul className="mt-3 divide-y divide-line">
          {entries.map((entry) => (
            <li key={entry.id} className="flex items-baseline justify-between gap-3 py-3">
              <div>
                <p className="font-medium">{entry.memberName}</p>
                <p className="text-sm text-muted">{entry.note || "Work"} · {formatDay(entry.workedOn)}</p>
              </div>
              <p className="font-semibold tabular-nums">{formatMinutes(entry.minutes)}</p>
            </li>
          ))}
          {entries.length === 0 ? <li className="py-3 text-sm text-muted">No time logged yet.</li> : null}
        </ul>
      </Card>
    </div>
  );
}

function ThreadTab({
  projectId,
  comments,
  staff,
}: {
  projectId: string;
  comments: { id: string; authorName: string; authorRole: string; body: string; visibility: string; createdAt: string }[];
  staff: boolean;
}) {
  const { run } = useStudio();
  const [body, setBody] = useState("");
  const [internal, setInternal] = useState(false);
  return (
    <Card>
      <h2 className="font-display text-xl font-semibold">Notes</h2>
      <ul className="mt-4 space-y-4">
        {comments.map((comment) => (
          <li key={comment.id} className="rounded-xl bg-paper p-3">
            <p className="text-sm text-muted">
              {comment.authorName}
              {comment.visibility === "team" ? " · team only" : ""}
              {" · "}
              {formatWhen(comment.createdAt)}
            </p>
            <p className="mt-1 whitespace-pre-wrap">{comment.body}</p>
          </li>
        ))}
        {comments.length === 0 ? <li className="text-sm text-muted">No notes yet. Say what changed.</li> : null}
      </ul>
      <form
        className="mt-4 space-y-3"
        onSubmit={(event) => {
          event.preventDefault();
          void run(() =>
            addComment({ data: { projectId, body, visibility: internal ? "team" : "client" } }),
          ).then((result) => {
            if (result.ok) setBody("");
          });
        }}
      >
        <textarea className={`${fieldClass} min-h-24 py-2`} value={body} onChange={(event) => setBody(event.target.value)} placeholder="Write a note" />
        {staff ? (
          <label className="flex min-h-11 items-center gap-3 text-sm">
            <input type="checkbox" checked={internal} onChange={(event) => setInternal(event.target.checked)} />
            Team only — the customer will not see this
          </label>
        ) : null}
        <Button type="submit">Post note</Button>
      </form>
    </Card>
  );
}
