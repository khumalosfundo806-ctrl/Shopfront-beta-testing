import { cn } from "@/lib/cn";

export function Mark({ className, title }: { className?: string; title?: string }) {
  return (
    <svg
      viewBox="0 0 80 72"
      className={cn("text-navy", className)}
      role={title ? "img" : "presentation"}
      aria-label={title}
      aria-hidden={title ? undefined : true}
    >
      <g
        fill="none"
        className="stroke-gold"
        strokeWidth="3.5"
        strokeLinecap="round"
      >
        <path d="M62 6c7 6 7 14 0 20" />
        <path d="M56 11c4 3.2 4 8 0 11.2" />
      </g>
      <circle cx="52.5" cy="22.5" r="2.6" className="fill-gold" />
      <path d="M8 34 36 12l28 22v2.5H8z" className="fill-current" />
      <path
        d="M10 33.5h52v5.2c-4.2 7-8.6 7-12.8 0-4.2 7-8.8 7-13 0-4.2 7-8.6 7-13 0-4.4 7-8.8 7-13.2 0v-5.2z"
        className="fill-gold"
      />
      <path d="M14 41h48v20H14z" className="fill-current" />
      <rect x="21" y="46" width="12" height="15" rx="1.2" className="fill-paper" />
      <rect x="39" y="46" width="16" height="10" rx="1.2" className="fill-paper" />
      <path d="M10 61h56v4.5H10z" className="fill-current" />
    </svg>
  );
}

export function Wordmark({
  light = false,
  className,
}: {
  light?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "font-display font-bold tracking-tight",
        light ? "text-paper" : "text-navy",
        className,
      )}
    >
      SHOPFRONT{" "}
      <span className={light ? "text-gold" : "text-gold-deep"}>DIGITAL</span>
    </span>
  );
}

export function BrandLockup({
  light = false,
  markClass = "h-10 w-10",
}: {
  light?: boolean;
  markClass?: string;
}) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <Mark className={markClass} />
      <Wordmark light={light} className="text-sm sm:text-base" />
    </span>
  );
}
