import { Link } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { StageStepper, ProjectLink, Stat } from "@/components/bits";
import { Button, Card, EmptyState } from "@/components/ui";
import { useStudio } from "@/components/shell";
import {
  STAGES,
  formatDay,
  formatMinutes,
  formatWhen,
  formatZar,
  invoiceTone,
  last7Days,
  stageMeta,
  waDigits,
} from "@/lib/studio-shared";

function greeting(name: string) {
  const hour = new Date().getHours();
  const hello = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  return `${hello}, ${name.split(" ")[0] || "there"}`;
}

export function Dashboard() {
  const { role, ws, projects, invoices, clients, viewingAsClient } = useStudio();
  if (role === "client") return <ClientHome />;
  const open = invoices.filter((invoice) => invoice.status !== "void" && invoice.status !== "paid" && invoice.balanceCents > 0);
  const outstanding = open.reduce((sum, invoice) => sum + invoice.balanceCents, 0);
  const active = projects.filter((project) => project.stage !== "delivered").length;
  const week = last7Days(ws.timeEntries);
  const weekMinutes = week.reduce((sum, day) => sum + day.minutes, 0);
  const allMinutes = ws.timeEntries.reduce((sum, entry) => sum + entry.minutes, 0);
  const chart = week.map((day) => ({
    label: day.label,
    hours: Math.round((day.minutes / 60) * 10) / 10,
  }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-gold-deep">{ws.studio.name}</p>
          <h1 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">{greeting(ws.me.name)}</h1>
          <p className="mt-2 max-w-xl text-muted">
            {clients.length} customers on the books. {formatMinutes(allMinutes)} logged in total.
          </p>
        </div>
        <Link to="/app/book">
          <Button variant="gold">New booking</Button>
        </Link>
      </div>
      {!viewingAsClient ? (
        <p className="text-sm text-muted">
          Five sample jobs are loaded so you can click through a real desk. A new booking sits beside them.
        </p>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Still to collect" value={formatZar(outstanding)} detail={`${open.length} open invoices`} />
        <Stat label="Customers" value={String(clients.length)} detail={`${active} jobs still open`} />
        <Stat label="Last 7 days" value={formatMinutes(weekMinutes)} detail="Time on client work" />
        <Stat
          label="Notices"
          value={String(ws.pendingPayments.length)}
          detail={ws.pendingPayments.length ? "Payments to confirm" : "No payment notices"}
        />
      </div>
      <Card>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-display text-xl font-semibold">Where the work sits</h2>
          <Link to="/app/projects" className="text-sm font-semibold text-gold-deep">
            All projects
          </Link>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {STAGES.map((stage) => {
            const items = projects.filter((project) => project.stage === stage.id);
            return (
              <div key={stage.id} className="w-56 shrink-0">
                <p className="mb-2 text-sm font-semibold">
                  {stage.short}
                  <span className="ml-2 tabular-nums text-muted">{items.length}</span>
                </p>
                <div className="space-y-2">
                  {items.map((project) => (
                    <Link
                      key={project.id}
                      to="/app/projects/$projectId"
                      params={{ projectId: project.id }}
                      className="block rounded-xl bg-paper p-3"
                    >
                      <p className="font-semibold">{project.clientName}</p>
                      <p className="mt-1 text-sm text-muted tabular-nums">
                        {project.balanceCents > 0 ? `${formatZar(project.balanceCents)} due` : formatMinutes(project.minutes)}
                      </p>
                    </Link>
                  ))}
                  {items.length === 0 ? <p className="rounded-xl bg-paper p-3 text-sm text-muted">Empty</p> : null}
                </div>
              </div>
            );
          })}
        </div>
      </Card>
      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <h2 className="font-display text-xl font-semibold">Hours, last 7 days</h2>
          <div className="mt-4 h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}>
                <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
                <Tooltip
                  cursor={{ fill: "var(--color-gold-soft)" }}
                  formatter={(value) => [`${value}h`, "Logged"]}
                />
                <Bar dataKey="hours" fill="var(--color-navy)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="lg:col-span-2">
          <h2 className="font-display text-xl font-semibold">Needs a look</h2>
          <ul className="mt-3 space-y-3">
            {ws.pendingPayments.map((payment) => (
              <li key={payment.id}>
                <Link to="/app/invoices/$invoiceId" params={{ invoiceId: payment.invoiceId }} className="block">
                  <p className="font-semibold">{payment.clientName} says they paid</p>
                  <p className="text-sm text-muted tabular-nums">
                    {formatZar(payment.amountCents)} · {payment.invoiceNumber}
                  </p>
                </Link>
              </li>
            ))}
            {open.slice(0, 4).map((invoice) => (
              <li key={invoice.id}>
                <Link to="/app/invoices/$invoiceId" params={{ invoiceId: invoice.id }} className="block">
                  <p className="font-semibold">{invoice.clientName}</p>
                  <p className="text-sm text-muted tabular-nums">
                    {invoice.number} · {formatZar(invoice.balanceCents)} · {invoiceTone(invoice.status, invoice.dueOn).label}
                  </p>
                </Link>
              </li>
            ))}
            {open.length === 0 && ws.pendingPayments.length === 0 ? (
              <li className="text-sm text-muted">Nothing waiting on money.</li>
            ) : null}
          </ul>
        </Card>
      </div>
      <Card>
        <h2 className="font-display text-xl font-semibold">Latest</h2>
        <ul className="mt-3 divide-y divide-line">
          {ws.activity.map((item) => (
            <li key={item.id} className="flex items-baseline justify-between gap-3 py-3">
              <p>{item.message}</p>
              <time className="shrink-0 text-sm text-muted">{formatWhen(item.createdAt)}</time>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function ClientHome() {
  const { ws, projects, invoices, clients, previewClient } = useStudio();
  const client = previewClient ?? clients[0];
  const project = projects[0];
  const balance = invoices
    .filter((invoice) => invoice.status !== "void" && invoice.status !== "paid")
    .reduce((sum, invoice) => sum + invoice.balanceCents, 0);
  const studioDigits = waDigits(ws.studio.whatsapp || ws.studio.phone);
  if (!project || !client) {
    return (
      <EmptyState
        title="No website on your desk yet"
        body="Tell us about the business and we’ll quote you before anything starts."
        action={
          <Link to="/app/book">
            <Button variant="gold">Book a website</Button>
          </Link>
        }
      />
    );
  }
  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm font-medium text-gold-deep">{client.businessName}</p>
        <h1 className="mt-1 font-display text-3xl font-semibold">{greeting(client.contactName)}</h1>
        <p className="mt-2 max-w-xl text-muted">{stageMeta(project.stage).client}. {stageMeta(project.stage).hint}</p>
      </div>
      <Card>
        <StageStepper stage={project.stage} />
        <div className="mt-5 flex flex-wrap gap-3">
          <Link to="/app/projects/$projectId" params={{ projectId: project.id }}>
            <Button>Open this project</Button>
          </Link>
          {studioDigits ? (
            <a href={`https://wa.me/${studioDigits}`} target="_blank" rel="noreferrer">
              <Button variant="whatsapp">WhatsApp the studio</Button>
            </a>
          ) : null}
        </div>
      </Card>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Balance due" value={formatZar(balance)} detail={balance ? "Pay the open invoice" : "Nothing owing"} />
        <Stat label="Time on your site" value={formatMinutes(project.minutes)} detail="Logged by the studio" />
        <Stat label="Package" value={project.quoteCents ? formatZar(project.quoteCents) : "Quote"} detail={project.dueOn ? `Due ${formatDay(project.dueOn)}` : "No due date yet"} />
      </div>
      {projects.length > 1 ? (
        <div className="grid gap-3 md:grid-cols-2">
          {projects.map((item) => (
            <ProjectLink key={item.id} project={item} />
          ))}
        </div>
      ) : null}
    </div>
  );
}
