import { Mark, Wordmark } from "@/components/logo";

export function Splash({ label = "Opening the studio" }: { label?: string }) {
  return (
    <div className="grid min-h-screen place-items-center bg-paper px-6">
      <div className="flex flex-col items-center gap-4 text-center">
        <Mark className="h-16 w-16" />
        <Wordmark className="text-lg" />
        <p className="text-sm text-muted">{label}</p>
      </div>
    </div>
  );
}
