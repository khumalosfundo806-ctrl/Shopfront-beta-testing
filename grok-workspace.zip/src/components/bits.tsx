import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/cn";
import {
  STAGES,
  daysOnProject,
  formatMinutes,
  formatZar,
  packageMeta,
  type ProjectCard,
} from "@/lib/studio-shared";
import { StageBadge } from "@/components/ui";

export function StageStepper({
  stage,
  onPick,
}: {
  stage: string;
  onPick?: (id: string) => void;
}) {
  const index = Math.max(0, STAGES.findIndex((item) => item.id === stage));
  const current = STAGES[index] ?? STAGES[0];
  return (
    <div>
      <div className="mb-2 flex items-end justify-between gap-3">
        <p className="font-display text-lg font-semibold">{current.client}</p>
        <p className="text-sm text-muted">{current.hint}</p>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-line" aria-hidden>
        <div
          className="h-full rounded-full bg-gold"
          style={{ width: `${((index + 1) / STAGES.length) * 100}%` }}
        />
      </div>
      <ol className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-8">
        {STAGES.map((item, itemIndex) => {
          const state = itemIndex < index ? "done" : itemIndex === index ? "now" : "todo";
          const className = cn(
            "flex min-h-11 w-full flex-col items-center justify-center rounded-xl px-1 text-sm font-semibold leading-tight",
            state === "now" && "bg-navy text-paper",
            state === "done" && "bg-gold-soft text-navy",
            state === "todo" && "bg-paper text-muted",
          );
          return (
            <li key={item.id}>
              {onPick ? (
                <button type="button" className={className} onClick={() => onPick(item.id)}>
                  {item.short}
                </button>
              ) : (
                <div className={className}>{item.short}</div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function ProjectLink({ project }: { project: ProjectCard }) {
  const pack = packageMeta(project.packageId);
  return (
    <Link
      to="/app/projects/$projectId"
      params={{ projectId: project.id }}
      className="block rounded-2xl bg-card p-4 shadow-card transition-shadow hover:shadow-card"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-display text-lg font-semibold">{project.clientName}</p>
          <p className="text-sm text-muted">{pack.name}</p>
        </div>
        <StageBadge stage={project.stage} />
      </div>
      <p className="mt-3 line-clamp-2 text-sm">{project.summary}</p>
      <dl className="mt-4 grid grid-cols-3 gap-2 text-sm">
        <div>
          <dt className="text-muted">Balance</dt>
          <dd className="font-semibold tabular-nums">{formatZar(project.balanceCents)}</dd>
        </div>
        <div>
          <dt className="text-muted">Paid</dt>
          <dd className="font-semibold tabular-nums">{formatZar(project.paidCents)}</dd>
        </div>
        <div>
          <dt className="text-muted">Time</dt>
          <dd className="font-semibold tabular-nums">{formatMinutes(project.minutes)}</dd>
        </div>
      </dl>
      <p className="mt-3 text-sm text-muted">
        {daysOnProject(project.createdAt, project.deliveredAt)} days
        {project.leadName ? ` · ${project.leadName}` : ""}
      </p>
    </Link>
  );
}

export function Stat({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-display text-3xl font-semibold tabular-nums">{value}</p>
      <p className="mt-1 text-sm text-muted">{detail}</p>
    </div>
  );
}
