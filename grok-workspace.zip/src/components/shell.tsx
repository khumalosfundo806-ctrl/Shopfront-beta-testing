import { useEffect, useState, type ReactNode } from "react";
import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Clock,
  FolderKanban,
  LayoutDashboard,
  Menu,
  Plus,
  Receipt,
  Settings,
  Square,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { cn } from "@/lib/cn";
import { loadWorkspace, stopTimer } from "@/lib/studio.functions";
import {
  formatMinutes,
  isStaff,
  type ClientCard,
  type InvoiceCard,
  type ProjectCard,
  type Result,
  type Role,
  type Workspace,
} from "@/lib/studio-shared";
import { Mark, Wordmark } from "@/components/logo";
import { Splash } from "@/components/splash";
import { createContext, useContext } from "react";

type StudioContextValue = {
  ws: Workspace;
  role: Role;
  realRole: Role;
  viewingAsClient: boolean;
  previewClient: ClientCard | null;
  setPreviewClient: (id: string | null) => void;
  projects: ProjectCard[];
  invoices: InvoiceCard[];
  clients: ClientCard[];
  run: <T extends object>(work: () => Promise<Result<T>>) => Promise<Result<T>>;
};

const StudioContext = createContext<StudioContextValue | null>(null);

export function useStudio() {
  const value = useContext(StudioContext);
  if (!value) throw new Error("Studio is not ready.");
  return value;
}

export function StudioProvider({ children }: { children: ReactNode }) {
  const [mounted, setMounted] = useState(false);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const qc = useQueryClient();
  useEffect(() => setMounted(true), []);
  const query = useQuery({
    queryKey: ["workspace"],
    queryFn: () => loadWorkspace(),
    enabled: mounted,
  });

  if (!mounted || query.isPending) return <Splash />;
  if (query.isError || !query.data) {
    const message = query.error instanceof Error ? query.error.message : "Could not open the studio.";
    if (/unauthorized/i.test(message)) return <RedirectToSignIn />;
    return (
      <div className="grid min-h-screen place-items-center bg-paper px-6">
        <div className="max-w-md text-center">
          <h1 className="font-display text-2xl font-semibold">The studio did not open</h1>
          <p className="mt-2 text-muted">{message}</p>
          <button
            type="button"
            className="mt-4 min-h-11 rounded-xl bg-navy px-4 text-sm font-semibold text-paper"
            onClick={() => void query.refetch()}
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  const ws = query.data;
  const previewClient = ws.clients.find((client) => client.id === previewId) ?? null;
  const viewingAsClient = Boolean(previewClient) && isStaff(ws.me.role);
  const role: Role = viewingAsClient ? "client" : ws.me.role;
  const projects =
    role === "client" ? ws.projects.filter((project) => project.clientId === (previewClient?.id ?? ws.me.clientId)) : ws.projects;
  const invoices =
    role === "client"
      ? ws.invoices.filter((invoice) => invoice.clientId === (previewClient?.id ?? ws.me.clientId))
      : ws.invoices;
  const clients = role === "client" ? ws.clients.filter((client) => client.id === (previewClient?.id ?? ws.me.clientId)) : ws.clients;

  async function run<T extends object>(work: () => Promise<Result<T>>): Promise<Result<T>> {
    try {
      const result = await work();
      if (!result.ok) {
        toast.error(result.error);
        return result;
      }
      await qc.invalidateQueries();
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not save.";
      toast.error(message);
      return { ok: false, error: message };
    }
  }

  return (
    <StudioContext.Provider
      value={{
        ws,
        role,
        realRole: ws.me.role,
        viewingAsClient,
        previewClient,
        setPreviewClient: setPreviewId,
        projects,
        invoices,
        clients,
        run,
      }}
    >
      {children}
    </StudioContext.Provider>
  );
}

const staffNav = [
  { to: "/app", label: "Overview", icon: LayoutDashboard, exact: true },
  { to: "/app/projects", label: "Projects", icon: FolderKanban, exact: false },
  { to: "/app/clients", label: "Customers", icon: Users, exact: false },
  { to: "/app/invoices", label: "Invoices", icon: Receipt, exact: false },
  { to: "/app/time", label: "Time", icon: Clock, exact: false },
  { to: "/app/team", label: "Team", icon: UserPlus, exact: false },
  { to: "/app/book", label: "New booking", icon: Plus, exact: false },
  { to: "/app/settings", label: "Settings", icon: Settings, exact: false },
] as const;

const clientNav = [
  { to: "/app", label: "My website", icon: LayoutDashboard, exact: true },
  { to: "/app/projects", label: "Projects", icon: FolderKanban, exact: false },
  { to: "/app/invoices", label: "Invoices", icon: Receipt, exact: false },
  { to: "/app/book", label: "Book", icon: Plus, exact: false },
] as const;

function NavLinks({ onDark }: { onDark: boolean }) {
  const { role } = useStudio();
  const items = role === "client" ? clientNav : staffNav;
  return (
    <nav className="flex flex-col gap-1">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            activeOptions={{ exact: item.exact }}
            className={cn(
              "flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium",
              onDark ? "text-paper hover:bg-paper/10" : "text-navy hover:bg-line",
            )}
            activeProps={{
              className: cn(
                "flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-semibold",
                onDark ? "bg-paper/10 text-gold" : "bg-navy text-paper",
              ),
            }}
          >
            <Icon className="size-4" aria-hidden />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

function TimerChip() {
  const { ws, role, run } = useStudio();
  const [now, setNow] = useState(() => Date.now());
  const running = Boolean(ws.timer) && role !== "client";
  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [running]);
  if (!ws.timer || role === "client") return null;
  const elapsed = Math.max(0, now - new Date(ws.timer.startedAt).getTime());
  const hours = Math.floor(elapsed / 3_600_000);
  const minutes = Math.floor((elapsed % 3_600_000) / 60_000);
  const seconds = Math.floor((elapsed % 60_000) / 1000);
  const clock = `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  return (
    <div className="flex items-center gap-2 rounded-full bg-gold px-3 py-1 text-navy">
      <Link to="/app/projects/$projectId" params={{ projectId: ws.timer.projectId }} className="text-sm font-semibold tabular-nums">
        {clock}
        <span className="ml-2 font-medium">{ws.timer.projectTitle}</span>
      </Link>
      <button
        type="button"
        className="grid size-8 place-items-center rounded-full bg-navy text-paper"
        aria-label="Stop timer"
        onClick={() =>
          void run(() => stopTimer()).then((result) => {
            if (result.ok && "minutes" in result) toast.success(`Logged ${formatMinutes(result.minutes)}`);
          })
        }
      >
        <Square className="size-3.5 fill-current" />
      </button>
    </div>
  );
}

export function Shell() {
  const { ws, role, viewingAsClient, previewClient, setPreviewClient, realRole } = useStudio();
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  useEffect(() => setOpen(false), [pathname]);

  return (
    <div className="min-h-screen bg-paper lg:grid lg:grid-cols-[16.5rem_1fr]">
      <aside className="no-print hidden bg-navy text-paper lg:flex lg:min-h-screen lg:flex-col lg:justify-between lg:px-4 lg:py-5">
        <div>
          <Link to="/app" className="flex items-center gap-2.5 px-2">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-paper">
              <Mark className="h-8 w-8" />
            </span>
            <Wordmark light className="text-sm" />
          </Link>
          <p className="mt-3 px-3 text-sm text-gold">{ws.studio.tagline}</p>
          <div className="mt-6">
            <NavLinks onDark />
          </div>
        </div>
        <div className="space-y-3 px-2">
          {isStaff(realRole) ? (
            <label className="block text-sm">
              <span className="mb-1 block text-paper/80">View as customer</span>
              <select
                className="min-h-11 w-full rounded-xl bg-navy-soft px-3 text-paper"
                value={previewClient?.id ?? ""}
                onChange={(event) => setPreviewClient(event.target.value || null)}
              >
                <option value="">Studio desk</option>
                {ws.clients.map((client) => (
                  <option key={client.id} value={client.id}>
                    {client.businessName}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
          <div className="text-paper">
            <UserButton />
          </div>
        </div>
      </aside>
      <div className="min-w-0">
        <header className="no-print sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-paper/95 px-4 py-3 backdrop-blur lg:px-8">
          <div className="flex items-center gap-2 lg:hidden">
            <button type="button" className="grid size-11 place-items-center rounded-xl bg-navy text-paper" aria-label="Open menu" onClick={() => setOpen(true)}>
              <Menu className="size-5" />
            </button>
            <Wordmark className="text-sm" />
          </div>
          <p className="hidden text-sm text-muted lg:block">
            {role === "client" ? "Your project" : ws.studio.location}
          </p>
          <TimerChip />
        </header>
        {viewingAsClient && previewClient ? (
          <div className="no-print flex flex-wrap items-center justify-between gap-3 bg-gold px-4 py-3 text-navy lg:px-8">
            <p className="text-sm font-medium">You are seeing what {previewClient.businessName} sees.</p>
            <button type="button" className="min-h-11 rounded-xl bg-navy px-4 text-sm font-semibold text-paper" onClick={() => setPreviewClient(null)}>
              Back to studio
            </button>
          </div>
        ) : null}
        <main id="main" className="mx-auto w-full max-w-6xl px-4 py-5 pb-28 sm:px-6 lg:px-8 lg:pb-10">
          <Outlet />
        </main>
      </div>
      {open ? (
        <div className="no-print fixed inset-0 z-40 lg:hidden">
          <button type="button" className="absolute inset-0 bg-navy/50" aria-label="Close menu" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-[min(100%,20rem)] flex-col bg-navy p-4 text-paper">
            <div className="mb-4 flex items-center justify-between">
              <Wordmark light className="text-sm" />
              <button type="button" className="grid size-11 place-items-center" aria-label="Close menu" onClick={() => setOpen(false)}>
                <X className="size-5" />
              </button>
            </div>
            <NavLinks onDark />
            <div className="mt-auto pt-6">
              <UserButton />
            </div>
          </div>
        </div>
      ) : null}
      <nav className="no-print fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-card lg:hidden">
        {(role === "client" ? clientNav : staffNav.slice(0, 4)).map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.exact }}
              className="flex min-h-14 flex-col items-center justify-center gap-1 text-sm text-muted"
              activeProps={{ className: "flex min-h-14 flex-col items-center justify-center gap-1 text-sm font-semibold text-navy" }}
            >
              <Icon className="size-4" aria-hidden />
              {item.label.split(" ")[0]}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
