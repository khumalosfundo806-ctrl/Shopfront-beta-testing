import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Mark, Wordmark } from "@/components/logo";
import { useStudio } from "@/components/shell";
import { Button, Card, Field, InvoiceBadge, fieldClass } from "@/components/ui";
import { loadInvoice, markInvoiceSent, recordPayment, resolvePayment, voidInvoice } from "@/lib/studio.functions";
import {
  PAY_METHODS,
  formatDay,
  formatZar,
  methodLabel,
  randsToCents,
  todayKey,
  waDigits,
  type InvoiceDetail,
} from "@/lib/studio-shared";

export function InvoiceScreen({ invoiceId }: { invoiceId: string }) {
  const { role, run } = useStudio();
  const query = useQuery({
    queryKey: ["invoice", invoiceId],
    queryFn: () => loadInvoice({ data: invoiceId }),
  });
  if (query.isPending) return <Card><p className="text-muted">Opening the invoice…</p></Card>;
  if (!query.data) return <Card><p>That invoice is not on your desk.</p></Card>;
  return <InvoiceBody detail={query.data} staff={role !== "client"} run={run} />;
}

function InvoiceBody({
  detail,
  staff,
  run,
}: {
  detail: InvoiceDetail;
  staff: boolean;
  run: ReturnType<typeof useStudio>["run"];
}) {
  const { invoice, lines, payments, studio, client } = detail;
  const { realRole } = useStudio();
  const [amount, setAmount] = useState(invoice.balanceCents > 0 ? String(invoice.balanceCents / 100) : "");
  const [method, setMethod] = useState("eft");
  const [reference, setReference] = useState(invoice.number);
  const [paidOn, setPaidOn] = useState(todayKey());
  const [confirmVoid, setConfirmVoid] = useState(false);

  const clientDigits = waDigits(client.whatsapp || client.phone);
  const studioDigits = waDigits(studio.whatsapp || studio.phone);
  const bank = studio.bankAccount
    ? `${studio.bankName}, account ${studio.bankAccount}${studio.bankBranch ? `, branch ${studio.bankBranch}` : ""}, ${studio.bankHolder}. Reference ${invoice.number}.`
    : `Reference ${invoice.number}. Add the account number in Settings before you send this.`;
  const toClient = `Hi ${client.contactName.split(" ")[0]}, invoice ${invoice.number} for ${client.businessName} is ${formatZar(invoice.totalCents)}. Paid ${formatZar(invoice.paidCents)}. Balance due ${formatZar(invoice.balanceCents)}. Pay by EFT: ${bank} — ${studio.name}`;
  const toStudio = `Hi, I've paid ${formatZar(invoice.balanceCents)} towards invoice ${invoice.number} for ${client.businessName}. Reference ${invoice.number}.`;

  function openWhatsApp(digits: string, message: string) {
    if (!digits) {
      void navigator.clipboard.writeText(message);
      toast.success("Message copied. Add a WhatsApp number to send it.");
      return;
    }
    window.open(`https://wa.me/${digits}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  }

  return (
    <div className="space-y-4">
      <div className="no-print flex flex-wrap gap-2">
        <Link to="/app/projects/$projectId" params={{ projectId: invoice.projectId }} className="text-sm font-semibold text-gold-deep">
          Back to {client.businessName}
        </Link>
      </div>
      <article className="print-sheet rounded-2xl bg-card p-5 shadow-card sm:p-8">
        <header className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-5">
          <div>
            <div className="flex items-center gap-2">
              <Mark className="h-10 w-10" />
              <Wordmark className="text-sm" />
            </div>
            <p className="mt-3 text-sm text-muted">{studio.location}</p>
            <p className="text-sm text-muted">{studio.phone}</p>
          </div>
          <div className="text-right">
            <p className="font-display text-3xl font-semibold">{invoice.number}</p>
            <div className="mt-2 flex justify-end">
              <InvoiceBadge status={invoice.status} dueOn={invoice.dueOn} />
            </div>
            <p className="mt-2 text-sm text-muted">Issued {formatDay(invoice.issuedOn)}</p>
            {invoice.dueOn ? <p className="text-sm text-muted">Due {formatDay(invoice.dueOn)}</p> : null}
          </div>
        </header>
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div>
            <p className="text-sm text-muted">Bill to</p>
            <p className="font-display text-xl font-semibold">{client.businessName}</p>
            <p>{client.contactName}</p>
            <p className="text-sm text-muted">{client.phone}</p>
            {client.location ? <p className="text-sm text-muted">{client.location}</p> : null}
          </div>
          <div>
            <p className="text-sm text-muted">For</p>
            <p className="font-semibold">{detail.projectTitle}</p>
            {invoice.notes ? <p className="mt-2 text-sm">{invoice.notes}</p> : null}
          </div>
        </div>
        <table className="mt-6 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-muted">
              <th className="py-2 font-medium">Description</th>
              <th className="py-2 text-right font-medium">Amount</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((line) => (
              <tr key={line.id} className="border-b border-line">
                <td className="py-3 pr-3">{line.description}</td>
                <td className="py-3 text-right tabular-nums">{formatZar(line.qty * line.unitCents)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <dl className="mt-4 ml-auto max-w-xs space-y-1 text-sm">
          <div className="flex justify-between gap-6">
            <dt className="text-muted">Total</dt>
            <dd className="font-semibold tabular-nums">{formatZar(invoice.totalCents)}</dd>
          </div>
          <div className="flex justify-between gap-6">
            <dt className="text-muted">Paid</dt>
            <dd className="tabular-nums">{formatZar(invoice.paidCents)}</dd>
          </div>
          <div className="flex justify-between gap-6 font-display text-xl font-semibold">
            <dt>Balance</dt>
            <dd className="tabular-nums">{formatZar(invoice.balanceCents)}</dd>
          </div>
        </dl>
        <div className="mt-6 rounded-xl bg-paper p-4">
          <p className="font-semibold">Pay by EFT</p>
          <p className="mt-1 text-sm">{bank}</p>
          <p className="mt-2 text-sm text-muted">Not a VAT invoice. The price on the quote does not change.</p>
        </div>
        {payments.length ? (
          <ul className="mt-4 space-y-2 text-sm">
            {payments.map((payment) => (
              <li key={payment.id} className="flex flex-wrap justify-between gap-2">
                <span>
                  {formatDay(payment.paidOn)} · {methodLabel(payment.method)}
                  {payment.reference ? ` · ${payment.reference}` : ""}
                  {payment.status === "pending" ? " · waiting to confirm" : ""}
                  {payment.status === "rejected" ? " · not matched" : ""}
                </span>
                <span className="tabular-nums">{formatZar(payment.amountCents)}</span>
              </li>
            ))}
          </ul>
        ) : null}
      </article>
      <div className="no-print flex flex-wrap gap-2">
        {staff ? (
          <Button
            variant="whatsapp"
            onClick={() => {
              void run(() => markInvoiceSent({ data: { invoiceId: invoice.id } })).then((result) => {
                if (result.ok) openWhatsApp(clientDigits, toClient);
              });
            }}
          >
            Send on WhatsApp
          </Button>
        ) : (
          <Button variant="whatsapp" onClick={() => openWhatsApp(studioDigits, toStudio)}>
            Tell the studio on WhatsApp
          </Button>
        )}
        <Button variant="line" onClick={() => window.print()}>
          Print / save PDF
        </Button>
        {realRole === "owner" && invoice.status !== "void" ? (
          confirmVoid ? (
            <Button
              variant="line"
              onClick={() => void run(() => voidInvoice({ data: { invoiceId: invoice.id } }))}
            >
              Confirm void
            </Button>
          ) : (
            <Button variant="line" onClick={() => setConfirmVoid(true)}>
              Void invoice
            </Button>
          )
        ) : null}
      </div>
      {invoice.status !== "void" && invoice.balanceCents > 0 ? (
        <Card className="no-print">
          <h2 className="font-display text-xl font-semibold">{staff ? "Record a payment" : "I've paid"}</h2>
          <p className="mt-1 text-sm text-muted">
            {staff
              ? "EFT, cash, card or PayFast. Confirmed payments update the balance."
              : "This tells the studio the money is on the way. They confirm it when it lands."}
          </p>
          <form
            className="mt-4 grid gap-3 sm:grid-cols-2"
            onSubmit={(event) => {
              event.preventDefault();
              const amountCents = randsToCents(amount);
              if (!amountCents) {
                toast.error("Enter the amount in rands.");
                return;
              }
              void run(() =>
                recordPayment({
                  data: {
                    invoiceId: invoice.id,
                    amountCents,
                    method,
                    reference,
                    paidOn,
                    pending: !staff,
                  },
                }),
              ).then((result) => {
                if (result.ok) toast.success(staff ? "Payment recorded." : "Sent to the studio to confirm.");
              });
            }}
          >
            <Field label="Amount in rands">
              <input className={fieldClass} inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} />
            </Field>
            <Field label="How">
              <select className={fieldClass} value={method} onChange={(event) => setMethod(event.target.value)}>
                {PAY_METHODS.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Reference">
              <input className={fieldClass} value={reference} onChange={(event) => setReference(event.target.value)} />
            </Field>
            <Field label="Date">
              <input className={fieldClass} type="date" value={paidOn} onChange={(event) => setPaidOn(event.target.value)} />
            </Field>
            <div className="sm:col-span-2">
              <Button type="submit">{staff ? "Record payment" : "Submit payment notice"}</Button>
            </div>
          </form>
        </Card>
      ) : null}
      {staff ? <PendingList invoiceId={invoice.id} /> : null}
    </div>
  );
}

function PendingList({ invoiceId }: { invoiceId: string }) {
  const { ws, run } = useStudio();
  const pending = ws.pendingPayments.filter((payment) => payment.invoiceId === invoiceId);
  if (!pending.length) return null;
  return (
    <Card className="no-print">
      <h2 className="font-display text-xl font-semibold">Waiting to confirm</h2>
      <ul className="mt-3 space-y-3">
        {pending.map((payment) => (
          <li key={payment.id} className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm">
              {formatZar(payment.amountCents)} · {methodLabel(payment.method)} · {payment.reference || "no reference"}
            </p>
            <div className="flex gap-2">
              <Button onClick={() => void run(() => resolvePayment({ data: { paymentId: payment.id, decision: "confirm" } }))}>
                Confirm
              </Button>
              <Button variant="line" onClick={() => void run(() => resolvePayment({ data: { paymentId: payment.id, decision: "reject" } }))}>
                Reject
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
}
