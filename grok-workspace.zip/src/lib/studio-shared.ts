export type Role = "owner" | "teammate" | "client";

export type Result<T extends object = object> =
  | ({ ok: true } & T)
  | { ok: false; error: string };

export const STAGES = [
  {
    id: "enquiry",
    label: "Enquiry",
    short: "Enquiry",
    client: "We have your request",
    hint: "Tell us what the business does.",
  },
  {
    id: "quote",
    label: "Quote",
    short: "Quote",
    client: "Your quote is ready",
    hint: "The price is set before we start.",
  },
  {
    id: "deposit",
    label: "Deposit",
    short: "Deposit",
    client: "Deposit due",
    hint: "Half starts the work.",
  },
  {
    id: "brief",
    label: "Brief",
    short: "Brief",
    client: "We need your photos and words",
    hint: "Logo, pictures, prices and colours.",
  },
  {
    id: "build",
    label: "Building",
    short: "Build",
    client: "We're building it",
    hint: "Usually a few days once we have everything.",
  },
  {
    id: "review",
    label: "Review",
    short: "Review",
    client: "Check it on your phone",
    hint: "Tell us what to change.",
  },
  {
    id: "balance",
    label: "Balance",
    short: "Balance",
    client: "Balance due",
    hint: "Pay the rest and the site is yours.",
  },
  {
    id: "delivered",
    label: "Delivered",
    short: "Live",
    client: "You're live",
    hint: "Customers can find you.",
  },
] as const;

export type StageId = (typeof STAGES)[number]["id"];

export const PACKAGES = [
  {
    id: "starter",
    name: "Starter bundle",
    priceCents: 150_000,
    blurb: "One-page mobile website, Google Business Profile and WhatsApp Business.",
    detail: "R1 500 once. Half to begin, the rest on delivery.",
  },
  {
    id: "premium",
    name: "Premium custom site",
    priceCents: 0,
    blurb: "Extra pages, galleries, your colours, a quote form and motion.",
    detail: "Quoted on what you need. The price does not change.",
  },
  {
    id: "pamphlets",
    name: "Pamphlets",
    priceCents: 50_000,
    blurb: "100 designed and printed pamphlets with a WhatsApp QR code.",
    detail: "R500 for 100. Designed, printed, delivered.",
  },
  {
    id: "care",
    name: "Monthly care",
    priceCents: 30_000,
    blurb: "Two small updates a month, renewals and a regular check.",
    detail: "R300 a month. 30 days’ notice to cancel.",
  },
] as const;

export type PackageId = (typeof PACKAGES)[number]["id"];

export const PAY_METHODS = [
  { id: "eft", label: "EFT" },
  { id: "cash", label: "Cash" },
  { id: "card", label: "Card" },
  { id: "payfast", label: "PayFast" },
] as const;

export const CHECKLIST = [
  "Logo",
  "Photos of the work",
  "Services and prices",
  "Opening hours",
  "Brand colours",
  "Words for the homepage",
  "WhatsApp number",
] as const;

export type Tone = "navy" | "gold" | "soft" | "line";

export type StudioInfo = {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  location: string;
  bankName: string;
  bankAccount: string;
  bankHolder: string;
  bankBranch: string;
  tagline: string;
};

export type ClientCard = {
  id: string;
  businessName: string;
  contactName: string;
  phone: string;
  email: string;
  whatsapp: string;
  location: string;
  notes: string;
  signedIn: boolean;
};

export type ProjectCard = {
  id: string;
  clientId: string;
  clientName: string;
  contactName: string;
  phone: string;
  title: string;
  packageId: string;
  stage: string;
  summary: string;
  quoteCents: number;
  invoicedCents: number;
  paidCents: number;
  pendingCents: number;
  balanceCents: number;
  minutes: number;
  leadName: string;
  dueOn: string | null;
  createdAt: string;
  deliveredAt: string | null;
};

export type InvoiceCard = {
  id: string;
  projectId: string;
  clientId: string;
  clientName: string;
  projectTitle: string;
  number: string;
  status: string;
  issuedOn: string;
  dueOn: string | null;
  notes: string;
  totalCents: number;
  paidCents: number;
  pendingCents: number;
  balanceCents: number;
};

export type TeamMember = {
  id: string;
  name: string;
  email: string;
  role: Role;
  title: string;
  linked: boolean;
};

export type ActivityItem = {
  id: string;
  message: string;
  createdAt: string;
  projectId: string | null;
};

export type TimeEntry = {
  id: string;
  projectId: string;
  projectTitle: string;
  memberName: string;
  minutes: number;
  note: string;
  workedOn: string;
};

export type PendingPayment = {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  clientName: string;
  amountCents: number;
  method: string;
  reference: string;
  paidOn: string;
};

export type Workspace = {
  me: {
    userId: string;
    name: string;
    email: string;
    role: Role;
    clientId: string | null;
    title: string;
  };
  studio: StudioInfo;
  clients: ClientCard[];
  projects: ProjectCard[];
  invoices: InvoiceCard[];
  team: TeamMember[];
  activity: ActivityItem[];
  timeEntries: TimeEntry[];
  pendingPayments: PendingPayment[];
  timer: { projectId: string; projectTitle: string; startedAt: string } | null;
};

export type Asset = {
  id: string;
  kind: "image" | "copy" | "video" | "color";
  title: string;
  body: string;
  url: string;
  color: string;
  createdAt: string;
};

export type CheckItem = { id: string; label: string; done: boolean };

export type Comment = {
  id: string;
  authorName: string;
  authorRole: string;
  body: string;
  visibility: "client" | "team";
  createdAt: string;
};

export type PaymentRow = {
  id: string;
  amountCents: number;
  method: string;
  reference: string;
  status: string;
  paidOn: string;
};

export type InvoiceLine = {
  id: string;
  description: string;
  qty: number;
  unitCents: number;
};

export type ProjectDetail = {
  project: ProjectCard;
  client: ClientCard;
  checklist: CheckItem[];
  assets: Asset[];
  comments: Comment[];
  entries: TimeEntry[];
  invoices: InvoiceCard[];
};

export type InvoiceDetail = {
  invoice: InvoiceCard;
  lines: InvoiceLine[];
  payments: PaymentRow[];
  studio: StudioInfo;
  client: ClientCard;
  projectTitle: string;
};

export function isStaff(role: string) {
  return role === "owner" || role === "teammate";
}

export function stageMeta(id: string) {
  return STAGES.find((stage) => stage.id === id) ?? STAGES[0];
}

export function packageMeta(id: string) {
  return PACKAGES.find((item) => item.id === id) ?? PACKAGES[0];
}

export function methodLabel(id: string) {
  return PAY_METHODS.find((item) => item.id === id)?.label ?? id;
}

export function formatZar(cents: number) {
  const negative = cents < 0;
  const abs = Math.abs(Math.round(cents));
  const rands = abs / 100;
  const hasCents = abs % 100 !== 0;
  const formatted = rands.toLocaleString("en-ZA", {
    minimumFractionDigits: hasCents ? 2 : 0,
    maximumFractionDigits: 2,
  });
  return `${negative ? "−" : ""}R${formatted}`;
}

export function formatMinutes(mins: number) {
  const m = Math.max(0, Math.round(mins));
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (h === 0) return `${r}m`;
  if (r === 0) return `${h}h`;
  return `${h}h ${r}m`;
}

export function todayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function formatDay(value: string | null | undefined) {
  if (!value) return "";
  const [y, m, d] = value.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return value;
  return new Date(y, m - 1, d).toLocaleDateString("en-ZA", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatWhen(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-ZA", { day: "numeric", month: "short" });
}

export function daysOnProject(createdAt: string, deliveredAt: string | null) {
  const start = new Date(createdAt).getTime();
  const end = deliveredAt ? new Date(deliveredAt).getTime() : Date.now();
  if (!Number.isFinite(start) || !Number.isFinite(end)) return 1;
  return Math.max(1, Math.round((end - start) / 86_400_000));
}

export function randsToCents(value: string) {
  const cleaned = value.replace(/[^\d.]/g, "");
  if (!cleaned) return null;
  const amount = Number(cleaned);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 10_000_000) return null;
  return Math.round(amount * 100);
}

export function invoiceTone(status: string, dueOn: string | null): { label: string; tone: Tone } {
  if (status === "paid") return { label: "Paid in full", tone: "navy" };
  if (status === "void") return { label: "Void", tone: "line" };
  if (status === "draft") return { label: "Draft", tone: "line" };
  if ((status === "sent" || status === "partial") && dueOn && dueOn < todayKey()) {
    return { label: "Overdue", tone: "gold" };
  }
  if (status === "partial") return { label: "Balance due", tone: "gold" };
  if (status === "sent") return { label: "Awaiting payment", tone: "soft" };
  return { label: status, tone: "line" };
}

export function stageTone(stage: string): { label: string; tone: Tone } {
  const meta = stageMeta(stage);
  if (stage === "delivered") return { label: meta.label, tone: "navy" };
  if (stage === "balance" || stage === "deposit") return { label: meta.label, tone: "gold" };
  return { label: meta.label, tone: "soft" };
}

export function waDigits(phone: string) {
  let digits = phone.replace(/\D/g, "");
  if (digits.startsWith("0")) digits = `27${digits.slice(1)}`;
  if (digits.length < 10) return "";
  return digits;
}

export function last7Days(entries: TimeEntry[]) {
  const days: { key: string; label: string; minutes: number }[] = [];
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    const key = todayKey(date);
    const label = date.toLocaleDateString("en-ZA", { weekday: "short" });
    const minutes = entries
      .filter((entry) => entry.workedOn.slice(0, 10) === key)
      .reduce((sum, entry) => sum + entry.minutes, 0);
    days.push({ key, label, minutes });
  }
  return days;
}
