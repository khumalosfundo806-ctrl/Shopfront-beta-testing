import { createServerFn } from "@tanstack/react-start";
import { getSql, type Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  CHECKLIST,
  PACKAGES,
  type ActivityItem,
  type Asset,
  type CheckItem,
  type ClientCard,
  type Comment,
  type InvoiceCard,
  type InvoiceDetail,
  type InvoiceLine,
  type PaymentRow,
  type PendingPayment,
  type ProjectCard,
  type ProjectDetail,
  type Result,
  type Role,
  type StudioInfo,
  type TeamMember,
  type TimeEntry,
  type Workspace,
} from "@/lib/studio-shared";

type Access = {
  userId: string;
  name: string;
  email: string;
  role: Role;
  memberId: string;
  clientId: string | null;
  studioId: string;
  title: string;
};

type MemberRow = {
  id: string;
  studio_id: string;
  user_id: string | null;
  client_id: string | null;
  email: string;
  name: string;
  role: string;
  title: string;
};

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function asIso(value: unknown) {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value) {
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) return date.toISOString();
  }
  return "";
}

function asDay(value: unknown) {
  if (!value) return null;
  if (typeof value === "string") return value.slice(0, 10);
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return null;
}

function text(value: unknown, max: number) {
  if (typeof value !== "string") return "";
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

function block(value: unknown, max: number) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function idOk(value: unknown): value is string {
  return typeof value === "string" && /^[a-zA-Z0-9_-]{1,80}$/.test(value);
}

function asRole(value: string): Role {
  if (value === "owner" || value === "teammate" || value === "client") return value;
  return "client";
}

function emailOk(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function hexColor(value: string) {
  const raw = value.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(raw)) return raw.toLowerCase();
  if (/^[0-9a-fA-F]{6}$/.test(raw)) return `#${raw.toLowerCase()}`;
  return "";
}

function safeUrl(value: string) {
  if (!value) return "";
  if (value.startsWith("data:image/")) {
    if (value.length > 700_000) return "";
    if (!/^data:image\/(png|jpe?g|gif|webp|svg\+xml)/i.test(value)) return "";
    if (/script/i.test(value.slice(0, 200))) return "";
    return value;
  }
  try {
    const url = new URL(value);
    if (url.protocol === "https:" || url.protocol === "http:") return url.toString().slice(0, 2000);
  } catch {
    return "";
  }
  return "";
}

function dayOk(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function fail(error: string): { ok: false; error: string } {
  return { ok: false, error };
}

async function identity(sql: Sql, userId: string) {
  const rows = await sql<{ name: string; email: string }>`
    select name, email from "user" where id = ${userId} limit 1
  `;
  return {
    name: (rows[0]?.name ?? "").trim(),
    email: (rows[0]?.email ?? "").trim(),
  };
}

async function findMember(sql: Sql, userId: string) {
  const rows = await sql<MemberRow>`
    select id, studio_id, user_id, client_id, email, name, role, title
    from members where user_id = ${userId} limit 1
  `;
  return rows[0] ?? null;
}

function toAccess(row: MemberRow, ident: { name: string; email: string }): Access {
  return {
    userId: row.user_id ?? "",
    name: ident.name || row.name,
    email: ident.email || row.email,
    role: asRole(row.role),
    memberId: row.id,
    clientId: row.client_id,
    studioId: row.studio_id,
    title: row.title,
  };
}

async function seedAll(sql: Sql, userId: string, name: string, email: string) {
  const ownerName = name || "Studio owner";
  await sql`
    insert into studios (id, name, phone, whatsapp, location, bank_name, bank_account, bank_holder, bank_branch, tagline)
    values ('shopfront', 'Shopfront Digital', '083 682 5921', '27836825921', 'Ntuzuma, Durban', 'Capitec', '', ${ownerName}, '', 'Get found online.')
    on conflict (id) do nothing
  `;
  await sql`
    insert into members (id, studio_id, user_id, client_id, email, name, role, title)
    values ('mem-owner', 'shopfront', ${userId}, null, ${email}, ${ownerName}, 'owner', 'Founder')
    on conflict (id) do nothing
  `;
  await sql`
    insert into members (id, studio_id, user_id, client_id, email, name, role, title) values
    ('mem-lindiwe', 'shopfront', null, null, 'lindiwe@shopfront.example', 'Lindiwe Ndlovu', 'teammate', 'Design'),
    ('mem-mandla', 'shopfront', null, null, 'mandla@shopfront.example', 'Mandla Cele', 'teammate', 'Google & WhatsApp')
    on conflict (id) do nothing
  `;

  const clients: [string, string, string, string, string, string, string][] = [
    ["client-jk", "JK Plumbers", "Thabo Mkhize", "061 482 1190", "thabo@jkplumbers.example", "278214821190", "Durban North"],
    ["client-laundry", "Laundromat Spot", "Ayesha Patel", "072 330 8841", "ayesha@laundromatspot.example", "27723308841", "Phoenix"],
    ["client-roof", "Ethekwini Roofing", "Sipho Dlamini", "082 915 4402", "sipho@ethekwinoroofing.example", "27829154402", "Pinetown"],
    ["client-bakery", "KwaMashu Bakery", "Nomsa Zulu", "063 221 7784", "nomsa@kwamashubakery.example", "27632217784", "KwaMashu"],
    ["client-hair", "Umlazi Hair Studio", "Lerato Molefe", "071 556 9033", "lerato@umlazihair.example", "27715569033", "Umlazi"],
  ];
  for (const [id, business, contact, phone, mail, whatsapp, location] of clients) {
    await sql`
      insert into clients (id, studio_id, user_id, business_name, contact_name, phone, email, whatsapp, location, notes)
      values (${id}, 'shopfront', null, ${business}, ${contact}, ${phone}, ${mail}, ${whatsapp}, ${location}, '')
      on conflict (id) do nothing
    `;
    await sql`
      insert into members (id, studio_id, user_id, client_id, email, name, role, title)
      values (${`mem-${id}`}, 'shopfront', null, ${id}, ${mail}, ${contact}, 'client', 'Client')
      on conflict (id) do nothing
    `;
  }
  await sql`update clients set notes = 'Site is live. They asked for a bigger call button, which is in.' where id = 'client-jk' and notes = ''`;
  await sql`update clients set notes = 'Reviewing on her phone this week. Balance is the second half.' where id = 'client-laundry' and notes = ''`;
  await sql`update clients set notes = 'Premium build. Waiting on a drone clip before review.' where id = 'client-roof' and notes = ''`;

  await sql`
    insert into projects (id, studio_id, client_id, title, package_id, stage, summary, quote_cents, lead_name, due_on, delivered_at, created_at)
    values
    ('proj-jk', 'shopfront', 'client-jk', 'JK Plumbers website', 'starter', 'delivered',
      'One-page site with callouts, geyser prices and a WhatsApp button.', 150000, ${ownerName}, current_date - 12, now() - interval '11 days', now() - interval '18 days'),
    ('proj-laundry', 'shopfront', 'client-laundry', 'Laundromat Spot website', 'starter', 'review',
      'Prices, hours and a wash-and-fold menu. She is checking it on her phone.', 150000, ${ownerName}, current_date + 2, null, now() - interval '9 days'),
    ('proj-roof', 'shopfront', 'client-roof', 'Ethekwini Roofing custom site', 'premium', 'build',
      'Gallery, quote form and brand colours. Drone clip still to come.', 850000, 'Lindiwe Ndlovu', current_date + 6, null, now() - interval '21 days'),
    ('proj-bakery', 'shopfront', 'client-bakery', 'KwaMashu Bakery website', 'starter', 'brief',
      'Starter site. We still need photos, prices and Sunday hours.', 150000, 'Mandla Cele', current_date + 5, null, now() - interval '4 days'),
    ('proj-hair', 'shopfront', 'client-hair', 'Umlazi Hair Studio enquiry', 'starter', 'enquiry',
      'New salon. Wants a one-page site in the same style as the laundromat.', 0, ${ownerName}, null, null, now() - interval '1 day')
    on conflict (id) do nothing
  `;

  const flags: Record<string, boolean[]> = {
    "proj-jk": [true, true, true, true, true, true, true],
    "proj-laundry": [true, true, true, true, true, true, true],
    "proj-roof": [true, true, true, false, true, true, true],
    "proj-bakery": [false, false, false, false, false, false, true],
    "proj-hair": [false, false, false, false, false, false, false],
  };
  for (const [projectId, done] of Object.entries(flags)) {
    for (let i = 0; i < CHECKLIST.length; i += 1) {
      await sql`
        insert into checklist_items (id, project_id, studio_id, label, done, sort)
        values (${`${projectId}-c${i}`}, ${projectId}, 'shopfront', ${CHECKLIST[i]}, ${done[i] ?? false}, ${i})
        on conflict (id) do nothing
      `;
    }
  }

  const tile = (letter: string, bg: string, fg: string) => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="500" viewBox="0 0 800 500"><rect width="800" height="500" fill="${bg}"/><circle cx="690" cy="90" r="80" fill="${fg}" opacity="0.18"/><text x="56" y="310" font-family="Georgia, serif" font-size="168" fill="${fg}">${letter}</text></svg>`;
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  };

  const assets: [string, string, string, string, string, string, string][] = [
    ["asset-jk-color", "proj-jk", "color", "Workwear navy", "", "", "#10233f"],
    ["asset-jk-color2", "proj-jk", "color", "Overall yellow", "", "", "#e3b01e"],
    ["asset-jk-copy", "proj-jk", "copy", "Homepage", "Emergency plumbers in Durban North. Geysers, leaks and blocked drains. Call or WhatsApp — we answer.", "", ""],
    ["asset-jk-img", "proj-jk", "image", "Logo tile", "Supplied logo, redrawn for the header.", tile("JK", "#10233F", "#E3B01E"), ""],
    ["asset-ld-copy", "proj-laundry", "copy", "Prices", "Wash and fold from R25/kg. Drop-off before 10:00, ready after 16:00. Open 7:00–19:00.", "", ""],
    ["asset-ld-color", "proj-laundry", "color", "Machine green", "", "", "#0c6e3c"],
    ["asset-ld-img", "proj-laundry", "image", "Shopfront photo", "Daytime photo of the roller door.", tile("LS", "#143D36", "#F3EFE6"), ""],
    ["asset-rf-copy", "proj-roof", "copy", "Services", "Repairs, new roofs and leak tracing across eThekwini. Send a photo on WhatsApp for a visit.", "", ""],
    ["asset-rf-color", "proj-roof", "color", "Roof brown", "", "", "#6b3a22"],
    ["asset-rf-color2", "proj-roof", "color", "Zinc", "", "", "#d7d2c8"],
    ["asset-rf-video", "proj-roof", "video", "Drone pass", "Film from the bakkie. Add a Drive link when it is exported.", "", ""],
    ["asset-bk-color", "proj-bakery", "color", "Bread crust", "Nomsa pointed at this from her apron.", "", "#c47a3a"],
  ];
  for (const [id, projectId, kind, title, body, url, color] of assets) {
    await sql`
      insert into assets (id, project_id, studio_id, kind, title, body, url, color, created_by)
      values (${id}, ${projectId}, 'shopfront', ${kind}, ${title}, ${body}, ${url}, ${color}, ${userId})
      on conflict (id) do nothing
    `;
  }

  await sql`
    insert into invoices (id, studio_id, project_id, client_id, number, status, issued_on, due_on, notes) values
    ('inv-jk', 'shopfront', 'proj-jk', 'client-jk', 'SF-1041', 'paid', current_date - 16, current_date - 12, 'Starter bundle. Paid in full by EFT.'),
    ('inv-laundry', 'shopfront', 'proj-laundry', 'client-laundry', 'SF-1042', 'partial', current_date - 8, current_date + 2, '50% deposit received. Balance when you approve the site.'),
    ('inv-roof', 'shopfront', 'proj-roof', 'client-roof', 'SF-1043', 'partial', current_date - 20, current_date + 6, 'Premium site. Deposit received. Balance on delivery.'),
    ('inv-bakery', 'shopfront', 'proj-bakery', 'client-bakery', 'SF-1044', 'sent', current_date - 3, current_date + 5, 'Starter bundle. 50% deposit to begin. The price does not change.')
    on conflict (id) do nothing
  `;
  await sql`
    insert into invoice_lines (id, invoice_id, description, qty, unit_cents, sort) values
    ('line-jk', 'inv-jk', 'Starter bundle — one-page website, Google Business Profile, WhatsApp Business', 1, 150000, 0),
    ('line-laundry', 'inv-laundry', 'Starter bundle — one-page website, Google Business Profile, WhatsApp Business', 1, 150000, 0),
    ('line-roof', 'inv-roof', 'Premium custom site — gallery, quote form, extra pages', 1, 850000, 0),
    ('line-bakery', 'inv-bakery', 'Starter bundle — one-page website, Google Business Profile, WhatsApp Business', 1, 150000, 0)
    on conflict (id) do nothing
  `;
  await sql`
    insert into payments (id, invoice_id, studio_id, amount_cents, method, reference, status, paid_on, recorded_by) values
    ('pay-jk', 'inv-jk', 'shopfront', 150000, 'eft', 'SF-1041', 'confirmed', current_date - 12, ${userId}),
    ('pay-laundry', 'inv-laundry', 'shopfront', 75000, 'eft', 'SF-1042 deposit', 'confirmed', current_date - 7, ${userId}),
    ('pay-roof', 'inv-roof', 'shopfront', 425000, 'eft', 'SF-1043 deposit', 'confirmed', current_date - 18, ${userId})
    on conflict (id) do nothing
  `;

  const times: [string, string, string, number, string, string][] = [
    ["time-1", "proj-roof", "Lindiwe Ndlovu", 180, "Homepage structure and gallery", "current_date - 1"],
    ["time-2", "proj-roof", "Lindiwe Ndlovu", 150, "Service pages", "current_date - 2"],
    ["time-3", "proj-roof", ownerName, 120, "Quote form and WhatsApp catalogue", "current_date"],
    ["time-4", "proj-roof", ownerName, 90, "Google Business Profile copy", "current_date - 3"],
    ["time-5", "proj-laundry", ownerName, 80, "Price changes after her notes", "current_date - 1"],
    ["time-6", "proj-laundry", ownerName, 100, "First build", "current_date - 6"],
    ["time-7", "proj-jk", ownerName, 200, "Build and launch", "current_date - 14"],
    ["time-8", "proj-jk", "Mandla Cele", 70, "Maps listing and photos", "current_date - 15"],
    ["time-9", "proj-bakery", "Mandla Cele", 40, "Started the Google profile", "current_date"],
    ["time-10", "proj-hair", ownerName, 25, "Read the enquiry", "current_date"],
  ];
  for (const [id, projectId, member, minutes, note, daySql] of times) {
    await sql.query(
      `insert into time_entries (id, project_id, studio_id, user_id, member_name, minutes, note, worked_on)
       values ($1, $2, 'shopfront', $3, $4, $5, $6, ${daySql})
       on conflict (id) do nothing`,
      [id, projectId, userId, member, minutes, note],
    );
  }

  await sql`
    insert into comments (id, project_id, studio_id, user_id, author_name, author_role, body, visibility, created_at) values
    ('cmt-1', 'proj-laundry', 'shopfront', ${userId}, 'Ayesha Patel', 'client',
      'Please put wash-and-fold prices above the fold. People ask that first.', 'client', now() - interval '2 days'),
    ('cmt-2', 'proj-laundry', 'shopfront', ${userId}, ${ownerName}, 'owner',
      'Done. Have a look on your phone and tell me if the green is too loud.', 'client', now() - interval '1 day'),
    ('cmt-3', 'proj-roof', 'shopfront', ${userId}, 'Lindiwe Ndlovu', 'teammate',
      'Gallery is in. Hold the review link until the drone clip arrives.', 'team', now() - interval '8 hours'),
    ('cmt-4', 'proj-bakery', 'shopfront', ${userId}, 'Mandla Cele', 'teammate',
      'Google profile is half done. Still need Sunday hours from Nomsa.', 'team', now() - interval '5 hours')
    on conflict (id) do nothing
  `;
  await sql`
    insert into activity (id, studio_id, project_id, user_id, message, created_at) values
    ('act-1', 'shopfront', 'proj-jk', ${userId}, 'JK Plumbers paid in full and went live.', now() - interval '11 days'),
    ('act-2', 'shopfront', 'proj-roof', ${userId}, 'Ethekwini Roofing deposit landed. Build started.', now() - interval '18 days'),
    ('act-3', 'shopfront', 'proj-laundry', ${userId}, 'Laundromat Spot moved to review.', now() - interval '1 day'),
    ('act-4', 'shopfront', 'proj-bakery', ${userId}, 'Quote SF-1044 sent to KwaMashu Bakery.', now() - interval '3 days'),
    ('act-5', 'shopfront', 'proj-hair', ${userId}, 'New enquiry from Umlazi Hair Studio.', now() - interval '1 day'),
    ('act-6', 'shopfront', 'proj-roof', ${userId}, 'Lindiwe logged time on the roofing gallery.', now() - interval '3 hours')
    on conflict (id) do nothing
  `;
}

async function ensureAccess(sql: Sql, userId: string): Promise<Access> {
  const ident = await identity(sql, userId);
  const existing = await findMember(sql, userId);
  if (existing) {
    if (existing.role === "owner") {
      const demo = await sql<{ id: string }>`select id from projects where id = 'proj-jk' limit 1`;
      if (!demo.length) await seedAll(sql, userId, ident.name || existing.name, ident.email || existing.email);
    }
    return toAccess(existing, ident);
  }

  if (ident.email) {
    const invited = await sql<MemberRow>`
      select id, studio_id, user_id, client_id, email, name, role, title
      from members
      where user_id is null and email <> '' and lower(email) = lower(${ident.email})
      limit 1
    `;
    const row = invited[0];
    if (row) {
      await sql`update members set user_id = ${userId} where id = ${row.id} and user_id is null`;
      if (row.client_id) {
        await sql`update clients set user_id = ${userId} where id = ${row.client_id}`;
      }
      const linked = await findMember(sql, userId);
      if (linked) return toAccess(linked, ident);
    }
  }

  const studio = await sql<{ id: string }>`select id from studios where id = 'shopfront' limit 1`;
  if (!studio.length) {
    await seedAll(sql, userId, ident.name, ident.email);
    const owner = await findMember(sql, userId);
    if (owner) return toAccess(owner, ident);
  }

  const owners = await sql<{ id: string }>`
    select id from members where studio_id = 'shopfront' and role = 'owner' limit 1
  `;
  if (!owners.length) {
    await seedAll(sql, userId, ident.name, ident.email);
    const owner = await findMember(sql, userId);
    if (owner) return toAccess(owner, ident);
  }

  const clientId = crypto.randomUUID();
  const memberId = crypto.randomUUID();
  const display = ident.name || "New customer";
  await sql`
    insert into clients (id, studio_id, user_id, business_name, contact_name, email)
    values (${clientId}, 'shopfront', ${userId}, ${display}, ${display}, ${ident.email})
  `;
  await sql`
    insert into members (id, studio_id, user_id, client_id, email, name, role, title)
    values (${memberId}, 'shopfront', ${userId}, ${clientId}, ${ident.email}, ${display}, 'client', 'Client')
  `;
  const created = await findMember(sql, userId);
  if (!created) throw new Error("Could not open your studio profile.");
  return toAccess(created, ident);
}

async function logAct(sql: Sql, studioId: string, userId: string, message: string, projectId: string | null) {
  await sql`
    insert into activity (id, studio_id, project_id, user_id, message)
    values (${crypto.randomUUID()}, ${studioId}, ${projectId}, ${userId}, ${message.slice(0, 280)})
  `;
}

type InvRow = {
  id: string;
  project_id: string;
  client_id: string;
  number: string;
  status: string;
  issued_on: string;
  due_on: string | null;
  notes: string;
  business_name: string;
  project_title: string;
  total_cents: number;
  paid_cents: number;
  pending_cents: number;
};

function mapInvoice(row: InvRow): InvoiceCard {
  const total = num(row.total_cents);
  const paid = num(row.paid_cents);
  const pending = num(row.pending_cents);
  return {
    id: row.id,
    projectId: row.project_id,
    clientId: row.client_id,
    clientName: row.business_name,
    projectTitle: row.project_title,
    number: row.number,
    status: row.status,
    issuedOn: asDay(row.issued_on) ?? "",
    dueOn: asDay(row.due_on),
    notes: row.notes,
    totalCents: total,
    paidCents: paid,
    pendingCents: pending,
    balanceCents: Math.max(0, total - paid),
  };
}

async function invoiceRows(sql: Sql, studioId: string, opts: { clientId?: string | null; projectId?: string | null }) {
  const params: unknown[] = [studioId];
  let where = "i.studio_id = $1";
  if (opts.clientId) {
    params.push(opts.clientId);
    where += ` and i.client_id = $${params.length}`;
  }
  if (opts.projectId) {
    params.push(opts.projectId);
    where += ` and i.project_id = $${params.length}`;
  }
  const rows = await sql.query<InvRow>(
    `select i.id, i.project_id, i.client_id, i.number, i.status,
            i.issued_on::text as issued_on, i.due_on::text as due_on, i.notes,
            c.business_name, p.title as project_title,
            coalesce((select sum(l.qty * l.unit_cents) from invoice_lines l where l.invoice_id = i.id), 0)::int as total_cents,
            coalesce((select sum(pay.amount_cents) from payments pay where pay.invoice_id = i.id and pay.status = 'confirmed'), 0)::int as paid_cents,
            coalesce((select sum(pay.amount_cents) from payments pay where pay.invoice_id = i.id and pay.status = 'pending'), 0)::int as pending_cents
     from invoices i
     join clients c on c.id = i.client_id
     join projects p on p.id = i.project_id
     where ${where}
     order by i.issued_on desc, i.number desc`,
    params,
  );
  return rows.map(mapInvoice);
}

async function projectRows(sql: Sql, a: Access, invoices: InvoiceCard[]) {
  const params: unknown[] = [a.studioId];
  let where = "p.studio_id = $1";
  if (a.role === "client") {
    params.push(a.clientId);
    where += " and p.client_id = $2";
  }
  const rows = await sql.query<{
    id: string;
    client_id: string;
    title: string;
    package_id: string;
    stage: string;
    summary: string;
    quote_cents: number;
    lead_name: string;
    due_on: string | null;
    created_at: unknown;
    delivered_at: unknown;
    business_name: string;
    contact_name: string;
    phone: string;
  }>(
    `select p.id, p.client_id, p.title, p.package_id, p.stage, p.summary, p.quote_cents, p.lead_name,
            p.due_on::text as due_on, p.created_at, p.delivered_at,
            c.business_name, c.contact_name, c.phone
     from projects p
     join clients c on c.id = p.client_id
     where ${where}
     order by p.updated_at desc`,
    params,
  );
  const minutes = await sql.query<{ project_id: string; minutes: number }>(
    `select project_id, coalesce(sum(minutes), 0)::int as minutes
     from time_entries where studio_id = $1 group by project_id`,
    [a.studioId],
  );
  const minuteMap = new Map(minutes.map((row) => [row.project_id, num(row.minutes)]));
  const money = new Map<string, { invoiced: number; paid: number; pending: number }>();
  for (const invoice of invoices) {
    if (invoice.status === "void") continue;
    const current = money.get(invoice.projectId) ?? { invoiced: 0, paid: 0, pending: 0 };
    current.invoiced += invoice.totalCents;
    current.paid += invoice.paidCents;
    current.pending += invoice.pendingCents;
    money.set(invoice.projectId, current);
  }
  return rows.map((row): ProjectCard => {
    const bag = money.get(row.id) ?? { invoiced: 0, paid: 0, pending: 0 };
    return {
      id: row.id,
      clientId: row.client_id,
      clientName: row.business_name,
      contactName: row.contact_name,
      phone: row.phone,
      title: row.title,
      packageId: row.package_id,
      stage: row.stage,
      summary: row.summary,
      quoteCents: num(row.quote_cents),
      invoicedCents: bag.invoiced,
      paidCents: bag.paid,
      pendingCents: bag.pending,
      balanceCents: Math.max(0, bag.invoiced - bag.paid),
      minutes: minuteMap.get(row.id) ?? 0,
      leadName: row.lead_name,
      dueOn: asDay(row.due_on),
      createdAt: asIso(row.created_at),
      deliveredAt: row.delivered_at ? asIso(row.delivered_at) : null,
    };
  });
}

async function studioOf(sql: Sql, studioId: string): Promise<StudioInfo> {
  const rows = await sql<{
    id: string;
    name: string;
    phone: string;
    whatsapp: string;
    location: string;
    bank_name: string;
    bank_account: string;
    bank_holder: string;
    bank_branch: string;
    tagline: string;
  }>`
    select id, name, phone, whatsapp, location, bank_name, bank_account, bank_holder, bank_branch, tagline
    from studios where id = ${studioId} limit 1
  `;
  const row = rows[0];
  if (!row) throw new Error("Studio not found.");
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    whatsapp: row.whatsapp,
    location: row.location,
    bankName: row.bank_name,
    bankAccount: row.bank_account,
    bankHolder: row.bank_holder,
    bankBranch: row.bank_branch,
    tagline: row.tagline,
  };
}

async function clientCards(sql: Sql, a: Access): Promise<ClientCard[]> {
  const params: unknown[] = [a.studioId];
  let where = "studio_id = $1";
  if (a.role === "client") {
    params.push(a.clientId);
    where += " and id = $2";
  }
  const rows = await sql.query<{
    id: string;
    business_name: string;
    contact_name: string;
    phone: string;
    email: string;
    whatsapp: string;
    location: string;
    notes: string;
    user_id: string | null;
  }>(
    `select id, business_name, contact_name, phone, email, whatsapp, location, notes, user_id
     from clients where ${where} order by business_name`,
    params,
  );
  return rows.map((row) => ({
    id: row.id,
    businessName: row.business_name,
    contactName: row.contact_name,
    phone: row.phone,
    email: row.email,
    whatsapp: row.whatsapp,
    location: row.location,
    notes: row.notes,
    signedIn: Boolean(row.user_id),
  }));
}

async function projectAccess(sql: Sql, a: Access, projectId: string) {
  if (!idOk(projectId)) return null;
  const rows = await sql<{ id: string; client_id: string; title: string; stage: string }>`
    select id, client_id, title, stage from projects
    where id = ${projectId} and studio_id = ${a.studioId} limit 1
  `;
  const row = rows[0];
  if (!row) return null;
  if (a.role === "client" && row.client_id !== a.clientId) return null;
  return row;
}

async function recomputeInvoice(sql: Sql, invoiceId: string) {
  const rows = await sql<{ status: string; total_cents: number; paid_cents: number }>`
    select i.status,
      coalesce((select sum(l.qty * l.unit_cents) from invoice_lines l where l.invoice_id = i.id), 0)::int as total_cents,
      coalesce((select sum(p.amount_cents) from payments p where p.invoice_id = i.id and p.status = 'confirmed'), 0)::int as paid_cents
    from invoices i where i.id = ${invoiceId} limit 1
  `;
  const row = rows[0];
  if (!row || row.status === "void") return;
  const total = num(row.total_cents);
  const paid = num(row.paid_cents);
  let status = "sent";
  if (paid >= total && total > 0) status = "paid";
  else if (paid > 0) status = "partial";
  else status = row.status === "draft" ? "draft" : "sent";
  if (status !== row.status) {
    await sql`update invoices set status = ${status} where id = ${invoiceId}`;
  }
}

async function maybeAdvance(sql: Sql, projectId: string, actorId: string, studioId: string) {
  const projects = await sql<{ stage: string; title: string }>`
    select stage, title from projects where id = ${projectId} limit 1
  `;
  const project = projects[0];
  if (!project) return;
  const paidRows = await sql<{ paid: number }>`
    select coalesce(sum(pay.amount_cents), 0)::int as paid
    from payments pay
    join invoices i on i.id = pay.invoice_id
    where i.project_id = ${projectId} and i.status <> 'void' and pay.status = 'confirmed'
  `;
  const totalRows = await sql<{ total: number }>`
    select coalesce(sum(l.qty * l.unit_cents), 0)::int as total
    from invoice_lines l
    join invoices i on i.id = l.invoice_id
    where i.project_id = ${projectId} and i.status <> 'void'
  `;
  const paid = num(paidRows[0]?.paid);
  const total = num(totalRows[0]?.total);
  if (paid > 0 && (project.stage === "enquiry" || project.stage === "quote" || project.stage === "deposit")) {
    await sql`update projects set stage = 'brief', updated_at = now() where id = ${projectId}`;
    await logAct(sql, studioId, actorId, `${project.title} deposit is in. Brief is open.`, projectId);
  } else if (total > 0 && paid >= total && project.stage === "balance") {
    await sql`
      update projects
      set stage = 'delivered', delivered_at = coalesce(delivered_at, now()), updated_at = now()
      where id = ${projectId}
    `;
    await logAct(sql, studioId, actorId, `${project.title} is paid in full and marked delivered.`, projectId);
  }
}

async function nextNumber(sql: Sql, studioId: string) {
  const rows = await sql<{ number: string }>`select number from invoices where studio_id = ${studioId}`;
  let max = 1040;
  for (const row of rows) {
    const match = /(\d+)$/.exec(row.number);
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `SF-${max + 1}`;
}

async function syncClientMember(sql: Sql, studioId: string, clientId: string, email: string, contact: string) {
  if (!email) return;
  const existing = await sql<{ id: string; role: string }>`
    select id, role from members where client_id = ${clientId} limit 1
  `;
  if (existing[0]) {
    await sql`update members set email = ${email}, name = ${contact} where id = ${existing[0].id}`;
    return;
  }
  const clash = await sql<{ id: string }>`
    select id from members where studio_id = ${studioId} and lower(email) = lower(${email}) limit 1
  `;
  if (clash.length) return;
  await sql`
    insert into members (id, studio_id, user_id, client_id, email, name, role, title)
    values (${crypto.randomUUID()}, ${studioId}, null, ${clientId}, ${email}, ${contact}, 'client', 'Client')
  `;
}

const PACKAGE_NOTES: Record<string, string> = {
  starter: "50% deposit to begin. Balance when the site is ready. The price does not change.",
  premium: "Custom site. Quoted before we start. The price does not change.",
  pamphlets: "100 pamphlets, designed, printed and delivered with a WhatsApp QR code.",
  care: "Monthly care — two small updates, renewals and checks. 30 days’ notice to cancel.",
};

export const loadWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Workspace> => {
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const staff = access.role !== "client";
    const studio = await studioOf(sql, access.studioId);
    const invoices = await invoiceRows(sql, access.studioId, {
      clientId: staff ? null : access.clientId,
    });
    const projects = await projectRows(sql, access, invoices);
    const clients = await clientCards(sql, access);
    const team: TeamMember[] = staff
      ? (
          await sql<{
            id: string;
            name: string;
            email: string;
            role: string;
            title: string;
            user_id: string | null;
          }>`
            select id, name, email, role, title, user_id from members
            where studio_id = ${access.studioId} and role <> 'client'
            order by case role when 'owner' then 0 else 1 end, name
          `
        ).map((row) => ({
          id: row.id,
          name: row.name,
          email: row.email,
          role: asRole(row.role),
          title: row.title,
          linked: Boolean(row.user_id),
        }))
      : [];
    const activity = (
      await sql.query<{ id: string; message: string; project_id: string | null; created_at: unknown }>(
        `select id, message, project_id, created_at from activity
         where studio_id = $1
           and ($2::text is null or project_id in (select id from projects where client_id = $2))
         order by created_at desc limit 20`,
        [access.studioId, staff ? null : access.clientId],
      )
    ).map(
      (row): ActivityItem => ({
        id: row.id,
        message: row.message,
        projectId: row.project_id,
        createdAt: asIso(row.created_at),
      }),
    );
    const timeEntries: TimeEntry[] = staff
      ? (
          await sql<{
            id: string;
            project_id: string;
            project_title: string;
            member_name: string;
            minutes: number;
            note: string;
            worked_on: string;
          }>`
            select t.id, t.project_id, p.title as project_title, t.member_name, t.minutes, t.note, t.worked_on::text as worked_on
            from time_entries t
            join projects p on p.id = t.project_id
            where t.studio_id = ${access.studioId}
            order by t.worked_on desc, t.created_at desc
            limit 400
          `
        ).map((row) => ({
          id: row.id,
          projectId: row.project_id,
          projectTitle: row.project_title,
          memberName: row.member_name,
          minutes: num(row.minutes),
          note: row.note,
          workedOn: asDay(row.worked_on) ?? "",
        }))
      : [];
    const pendingPayments: PendingPayment[] = staff
      ? (
          await sql<{
            id: string;
            invoice_id: string;
            amount_cents: number;
            method: string;
            reference: string;
            paid_on: string;
            number: string;
            business_name: string;
          }>`
            select pay.id, pay.invoice_id, pay.amount_cents, pay.method, pay.reference, pay.paid_on::text as paid_on,
                   i.number, c.business_name
            from payments pay
            join invoices i on i.id = pay.invoice_id
            join clients c on c.id = i.client_id
            where pay.studio_id = ${access.studioId} and pay.status = 'pending'
            order by pay.created_at desc
          `
        ).map((row) => ({
          id: row.id,
          invoiceId: row.invoice_id,
          invoiceNumber: row.number,
          clientName: row.business_name,
          amountCents: num(row.amount_cents),
          method: row.method,
          reference: row.reference,
          paidOn: asDay(row.paid_on) ?? "",
        }))
      : [];
    const timers = staff
      ? await sql<{ project_id: string; started_at: unknown; title: string }>`
          select t.project_id, t.started_at, p.title
          from timers t join projects p on p.id = t.project_id
          where t.user_id = ${access.userId} and t.studio_id = ${access.studioId}
          limit 1
        `
      : [];
    const timer = timers[0]
      ? { projectId: timers[0].project_id, projectTitle: timers[0].title, startedAt: asIso(timers[0].started_at) }
      : null;
    return {
      me: {
        userId: access.userId,
        name: access.name,
        email: access.email,
        role: access.role,
        clientId: access.clientId,
        title: access.title,
      },
      studio,
      clients,
      projects,
      invoices,
      team,
      activity,
      timeEntries,
      pendingPayments,
      timer,
    };
  });

export const loadProject = createServerFn({ method: "GET" })
  .validator((projectId: string) => {
    if (!idOk(projectId)) throw new Error("Unknown project.");
    return projectId;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<ProjectDetail | null> => {
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const allowed = await projectAccess(sql, access, data);
    if (!allowed) return null;
    const invoices = await invoiceRows(sql, access.studioId, { projectId: data });
    const projects = await projectRows(sql, access, invoices);
    const project = projects.find((item) => item.id === data);
    if (!project) return null;
    const clients = await clientCards(sql, { ...access, role: "client", clientId: project.clientId });
    const client = clients[0];
    if (!client) return null;
    const checklist = (
      await sql<{ id: string; label: string; done: boolean }>`
        select id, label, done from checklist_items
        where project_id = ${data} order by sort, label
      `
    ).map((row): CheckItem => ({ id: row.id, label: row.label, done: row.done === true }));
    const assets = (
      await sql<{
        id: string;
        kind: string;
        title: string;
        body: string;
        url: string;
        color: string;
        created_at: unknown;
      }>`
        select id, kind, title, body, url, color, created_at from assets
        where project_id = ${data} order by created_at
      `
    ).map((row): Asset => ({
      id: row.id,
      kind: row.kind === "image" || row.kind === "copy" || row.kind === "video" || row.kind === "color" ? row.kind : "copy",
      title: row.title,
      body: row.body,
      url: row.url,
      color: row.color,
      createdAt: asIso(row.created_at),
    }));
    const comments = (
      await sql.query<{
        id: string;
        author_name: string;
        author_role: string;
        body: string;
        visibility: string;
        created_at: unknown;
      }>(
        `select id, author_name, author_role, body, visibility, created_at
         from comments where project_id = $1 and ($2::boolean or visibility = 'client')
         order by created_at`,
        [data, access.role !== "client"],
      )
    ).map((row): Comment => ({
      id: row.id,
      authorName: row.author_name,
      authorRole: row.author_role,
      body: row.body,
      visibility: row.visibility === "team" ? "team" : "client",
      createdAt: asIso(row.created_at),
    }));
    const entries =
      access.role === "client"
        ? []
        : (
            await sql<{
              id: string;
              member_name: string;
              minutes: number;
              note: string;
              worked_on: string;
            }>`
              select id, member_name, minutes, note, worked_on::text as worked_on
              from time_entries where project_id = ${data}
              order by worked_on desc, created_at desc
            `
          ).map((row): TimeEntry => ({
            id: row.id,
            projectId: data,
            projectTitle: project.title,
            memberName: row.member_name,
            minutes: num(row.minutes),
            note: row.note,
            workedOn: asDay(row.worked_on) ?? "",
          }));
    return { project, client, checklist, assets, comments, entries, invoices };
  });

export const loadInvoice = createServerFn({ method: "GET" })
  .validator((invoiceId: string) => {
    if (!idOk(invoiceId)) throw new Error("Unknown invoice.");
    return invoiceId;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<InvoiceDetail | null> => {
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const invoices = await invoiceRows(sql, access.studioId, {
      clientId: access.role === "client" ? access.clientId : null,
    });
    const invoice = invoices.find((item) => item.id === data);
    if (!invoice) return null;
    const lines = (
      await sql<{ id: string; description: string; qty: number; unit_cents: number }>`
        select id, description, qty, unit_cents from invoice_lines
        where invoice_id = ${data} order by sort, id
      `
    ).map((row): InvoiceLine => ({
      id: row.id,
      description: row.description,
      qty: num(row.qty) || 1,
      unitCents: num(row.unit_cents),
    }));
    const payments = (
      await sql<{
        id: string;
        amount_cents: number;
        method: string;
        reference: string;
        status: string;
        paid_on: string;
      }>`
        select id, amount_cents, method, reference, status, paid_on::text as paid_on
        from payments where invoice_id = ${data} order by paid_on, created_at
      `
    )
      .map((row): PaymentRow => ({
        id: row.id,
        amountCents: num(row.amount_cents),
        method: row.method,
        reference: row.reference,
        status: row.status,
        paidOn: asDay(row.paid_on) ?? "",
      }))
      .filter((row) => access.role !== "client" || row.status !== "rejected");
    const clients = await clientCards(sql, { ...access, role: "client", clientId: invoice.clientId });
    const client = clients[0];
    if (!client) return null;
    const studio = await studioOf(sql, access.studioId);
    return { invoice, lines, payments, studio, client, projectTitle: invoice.projectTitle };
  });

type BookingInput = {
  businessName: string;
  contactName: string;
  phone: string;
  email: string;
  whatsapp: string;
  location: string;
  packageId: string;
  brief: string;
  quoteCents: number;
};

export const createBooking = createServerFn({ method: "POST" })
  .validator((input: BookingInput) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result<{ projectId: string }>> => {
    const business = text(data.businessName, 120);
    const contact = text(data.contactName, 120);
    const phone = text(data.phone, 40);
    const email = text(data.email, 160).toLowerCase();
    const whatsapp = text(data.whatsapp, 40);
    const location = text(data.location, 120);
    const brief = block(data.brief, 2000);
    const packageId = text(data.packageId, 40);
    const pack = PACKAGES.find((item) => item.id === packageId);
    if (!business) return fail("Add the business name.");
    if (!contact) return fail("Add a contact name.");
    if (!pack) return fail("Choose a package.");
    if (email && !emailOk(email)) return fail("That email does not look right.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    let clientId = access.role === "client" ? access.clientId : null;
    if (access.role === "client") {
      if (!clientId) return fail("Your customer profile is missing.");
      await sql`
        update clients
        set business_name = ${business}, contact_name = ${contact}, phone = ${phone},
            email = ${email}, whatsapp = ${whatsapp}, location = ${location}
        where id = ${clientId} and studio_id = ${access.studioId}
      `;
      await syncClientMember(sql, access.studioId, clientId, email, contact);
    } else {
      const found = await sql<{ id: string }>`
        select id from clients
        where studio_id = ${access.studioId} and lower(business_name) = lower(${business})
        limit 1
      `;
      if (found[0]) {
        clientId = found[0].id;
        await sql`
          update clients
          set contact_name = ${contact},
              phone = case when ${phone} = '' then phone else ${phone} end,
              email = case when ${email} = '' then email else ${email} end,
              whatsapp = case when ${whatsapp} = '' then whatsapp else ${whatsapp} end,
              location = case when ${location} = '' then location else ${location} end
          where id = ${clientId}
        `;
      } else {
        clientId = crypto.randomUUID();
        await sql`
          insert into clients (id, studio_id, user_id, business_name, contact_name, phone, email, whatsapp, location, notes)
          values (${clientId}, ${access.studioId}, null, ${business}, ${contact}, ${phone}, ${email}, ${whatsapp}, ${location}, '')
        `;
      }
      await syncClientMember(sql, access.studioId, clientId, email, contact);
    }
    const quoteCents =
      pack.priceCents > 0 ? pack.priceCents : Math.max(0, Math.round(num(data.quoteCents)));
    const stage = quoteCents > 0 ? "quote" : "enquiry";
    const projectId = crypto.randomUUID();
    await sql`
      insert into projects (id, studio_id, client_id, title, package_id, stage, summary, quote_cents, lead_name, due_on)
      values (
        ${projectId}, ${access.studioId}, ${clientId}, ${`${business} website`}, ${pack.id}, ${stage},
        ${brief || pack.blurb}, ${quoteCents}, ${access.name}, current_date + 7
      )
    `;
    for (let i = 0; i < CHECKLIST.length; i += 1) {
      const done = CHECKLIST[i] === "WhatsApp number" && Boolean(whatsapp || phone);
      await sql`
        insert into checklist_items (id, project_id, studio_id, label, done, sort)
        values (${crypto.randomUUID()}, ${projectId}, ${access.studioId}, ${CHECKLIST[i]}, ${done}, ${i})
      `;
    }
    if (brief) {
      await sql`
        insert into assets (id, project_id, studio_id, kind, title, body, url, color, created_by)
        values (${crypto.randomUUID()}, ${projectId}, ${access.studioId}, 'copy', 'About the business', ${brief}, '', '', ${access.userId})
      `;
    }
    if (quoteCents > 0) {
      const invoiceId = crypto.randomUUID();
      const number = await nextNumber(sql, access.studioId);
      await sql`
        insert into invoices (id, studio_id, project_id, client_id, number, status, issued_on, due_on, notes)
        values (${invoiceId}, ${access.studioId}, ${projectId}, ${clientId}, ${number}, 'sent', current_date, current_date + 7, ${PACKAGE_NOTES[pack.id] ?? ""})
      `;
      await sql`
        insert into invoice_lines (id, invoice_id, description, qty, unit_cents, sort)
        values (${crypto.randomUUID()}, ${invoiceId}, ${`${pack.name} — ${pack.blurb}`}, 1, ${quoteCents}, 0)
      `;
    }
    await logAct(sql, access.studioId, access.userId, `New booking: ${business} · ${pack.name}.`, projectId);
    return { ok: true, projectId };
  });

export const updateStage = createServerFn({ method: "POST" })
  .validator((input: { projectId: string; stage: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const stage = text(data.stage, 20);
    if (!["enquiry", "quote", "deposit", "brief", "build", "review", "balance", "delivered"].includes(stage)) {
      return fail("Unknown stage.");
    }
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Only the studio team moves the stage.");
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    if (stage === "delivered") {
      await sql`
        update projects set stage = ${stage}, delivered_at = coalesce(delivered_at, now()), updated_at = now()
        where id = ${project.id}
      `;
    } else {
      await sql`
        update projects set stage = ${stage}, delivered_at = null, updated_at = now()
        where id = ${project.id}
      `;
    }
    await logAct(sql, access.studioId, access.userId, `${project.title} moved to ${stage}.`, project.id);
    return { ok: true };
  });

export const updateProject = createServerFn({ method: "POST" })
  .validator((input: { projectId: string; summary: string; quoteCents: number; leadName: string; dueOn: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const summary = block(data.summary, 2000);
    const leadName = text(data.leadName, 120);
    const dueOn = text(data.dueOn, 10);
    const quoteCents = Math.max(0, Math.round(num(data.quoteCents)));
    if (dueOn && !dayOk(dueOn)) return fail("Use a real due date.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Only the studio team edits the job details.");
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    await sql`
      update projects
      set summary = ${summary}, quote_cents = ${quoteCents}, lead_name = ${leadName},
          due_on = ${dueOn || null}, updated_at = now()
      where id = ${project.id}
    `;
    return { ok: true };
  });

export const addAsset = createServerFn({ method: "POST" })
  .validator((input: { projectId: string; kind: string; title: string; body: string; url: string; color: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const kind = text(data.kind, 20);
    if (!["image", "copy", "video", "color"].includes(kind)) return fail("Unknown brief item.");
    const title = text(data.title, 140);
    const body = block(data.body, 4000);
    const color = hexColor(text(data.color, 20));
    const url = safeUrl(typeof data.url === "string" ? data.url.trim() : "");
    if (!title) return fail("Add a short title.");
    if (kind === "color" && !color) return fail("Use a colour like #10233F.");
    if (kind === "copy" && !body) return fail("Add the words.");
    if ((kind === "image" || kind === "video") && !url && !body) return fail("Add a link, a file, or a note.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    await sql`
      insert into assets (id, project_id, studio_id, kind, title, body, url, color, created_by)
      values (${crypto.randomUUID()}, ${project.id}, ${access.studioId}, ${kind}, ${title}, ${body}, ${url}, ${color}, ${access.userId})
    `;
    await sql`update projects set updated_at = now() where id = ${project.id}`;
    if (access.role === "client") {
      await logAct(sql, access.studioId, access.userId, `${access.name} added ${title} to ${project.title}.`, project.id);
    }
    return { ok: true };
  });

export const deleteAsset = createServerFn({ method: "POST" })
  .validator((input: { assetId: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.assetId)) return fail("Unknown item.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const rows = await sql<{ project_id: string; created_by: string; studio_id: string }>`
      select project_id, created_by, studio_id from assets where id = ${data.assetId} limit 1
    `;
    const row = rows[0];
    if (!row || row.studio_id !== access.studioId) return fail("That item is not in your studio.");
    const project = await projectAccess(sql, access, row.project_id);
    if (!project) return fail("That item is not in your studio.");
    if (access.role === "client" && row.created_by !== access.userId) {
      return fail("You can remove things you added.");
    }
    await sql`delete from assets where id = ${data.assetId}`;
    return { ok: true };
  });

export const toggleCheck = createServerFn({ method: "POST" })
  .validator((input: { itemId: string; done: boolean }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.itemId)) return fail("Unknown item.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const rows = await sql<{ project_id: string }>`
      select project_id from checklist_items where id = ${data.itemId} and studio_id = ${access.studioId} limit 1
    `;
    const row = rows[0];
    if (!row) return fail("That item is not in your studio.");
    const project = await projectAccess(sql, access, row.project_id);
    if (!project) return fail("That item is not in your studio.");
    await sql`update checklist_items set done = ${Boolean(data.done)} where id = ${data.itemId}`;
    return { ok: true };
  });

export const addComment = createServerFn({ method: "POST" })
  .validator((input: { projectId: string; body: string; visibility: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const body = block(data.body, 2000);
    if (!body) return fail("Write a note first.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    const visibility = access.role === "client" || text(data.visibility, 20) !== "team" ? "client" : "team";
    await sql`
      insert into comments (id, project_id, studio_id, user_id, author_name, author_role, body, visibility)
      values (
        ${crypto.randomUUID()}, ${project.id}, ${access.studioId}, ${access.userId},
        ${access.name}, ${access.role}, ${body}, ${visibility}
      )
    `;
    if (visibility === "client") {
      await logAct(sql, access.studioId, access.userId, `${access.name} wrote on ${project.title}.`, project.id);
    }
    return { ok: true };
  });

export const logTime = createServerFn({ method: "POST" })
  .validator((input: { projectId: string; minutes: number; note: string; workedOn: string; memberName: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const minutes = Math.round(num(data.minutes));
    if (minutes < 1 || minutes > 24 * 60) return fail("Log between 1 minute and 24 hours.");
    const workedOn = text(data.workedOn, 10);
    if (!dayOk(workedOn)) return fail("Pick the day you worked.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Time is logged by the studio.");
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    const memberName = text(data.memberName, 120) || access.name;
    await sql`
      insert into time_entries (id, project_id, studio_id, user_id, member_name, minutes, note, worked_on)
      values (
        ${crypto.randomUUID()}, ${project.id}, ${access.studioId}, ${access.userId},
        ${memberName}, ${minutes}, ${text(data.note, 280)}, ${workedOn}
      )
    `;
    return { ok: true };
  });

export const deleteTime = createServerFn({ method: "POST" })
  .validator((input: { entryId: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.entryId)) return fail("Unknown entry.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Time is logged by the studio.");
    await sql`delete from time_entries where id = ${data.entryId} and studio_id = ${access.studioId}`;
    return { ok: true };
  });

export const startTimer = createServerFn({ method: "POST" })
  .validator((input: { projectId: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Timers are for the studio.");
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    const current = await sql<{ project_id: string }>`
      select project_id from timers where user_id = ${access.userId} limit 1
    `;
    if (current[0] && current[0].project_id !== project.id) {
      return fail("Stop the timer that is already running first.");
    }
    if (!current[0]) {
      await sql`
        insert into timers (user_id, studio_id, project_id, started_at)
        values (${access.userId}, ${access.studioId}, ${project.id}, now())
      `;
    }
    return { ok: true };
  });

export const stopTimer = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Result<{ minutes: number }>> => {
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Timers are for the studio.");
    const rows = await sql<{ project_id: string; started_at: unknown }>`
      select project_id, started_at from timers where user_id = ${access.userId} limit 1
    `;
    const timer = rows[0];
    if (!timer) return fail("No timer is running.");
    const started = new Date(asIso(timer.started_at)).getTime();
    const minutes = Math.max(1, Math.min(24 * 60, Math.round((Date.now() - started) / 60000)));
    await sql`
      insert into time_entries (id, project_id, studio_id, user_id, member_name, minutes, note, worked_on)
      values (${crypto.randomUUID()}, ${timer.project_id}, ${access.studioId}, ${access.userId}, ${access.name}, ${minutes}, 'Timer', current_date)
    `;
    await sql`delete from timers where user_id = ${access.userId}`;
    return { ok: true, minutes };
  });

export const createInvoice = createServerFn({ method: "POST" })
  .validator((input: { projectId: string; notes: string; dueOn: string; lines: { description: string; unitCents: number }[] }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result<{ invoiceId: string }>> => {
    if (!idOk(data.projectId)) return fail("Unknown project.");
    const lines = Array.isArray(data.lines) ? data.lines.slice(0, 8) : [];
    const clean = lines
      .map((line) => ({
        description: text(line?.description, 240),
        unitCents: Math.round(num(line?.unitCents)),
      }))
      .filter((line) => line.description && line.unitCents > 0);
    if (!clean.length) return fail("Add at least one line with an amount.");
    const dueOn = text(data.dueOn, 10);
    if (dueOn && !dayOk(dueOn)) return fail("Use a real due date.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Only the studio sends invoices.");
    const project = await projectAccess(sql, access, data.projectId);
    if (!project) return fail("That project is not in your studio.");
    const full = await sql<{ client_id: string; title: string }>`
      select client_id, title from projects where id = ${project.id} limit 1
    `;
    const clientId = full[0]?.client_id;
    if (!clientId) return fail("That project has no customer.");
    const invoiceId = crypto.randomUUID();
    const number = await nextNumber(sql, access.studioId);
    if (dueOn) {
      await sql`
        insert into invoices (id, studio_id, project_id, client_id, number, status, issued_on, due_on, notes)
        values (${invoiceId}, ${access.studioId}, ${project.id}, ${clientId}, ${number}, 'draft', current_date, ${dueOn}, ${block(data.notes, 800)})
      `;
    } else {
      await sql`
        insert into invoices (id, studio_id, project_id, client_id, number, status, issued_on, due_on, notes)
        values (${invoiceId}, ${access.studioId}, ${project.id}, ${clientId}, ${number}, 'draft', current_date, current_date + 7, ${block(data.notes, 800)})
      `;
    }
    for (let i = 0; i < clean.length; i += 1) {
      const line = clean[i];
      if (!line) continue;
      await sql`
        insert into invoice_lines (id, invoice_id, description, qty, unit_cents, sort)
        values (${crypto.randomUUID()}, ${invoiceId}, ${line.description}, 1, ${line.unitCents}, ${i})
      `;
    }
    await logAct(sql, access.studioId, access.userId, `Draft invoice ${number} for ${full[0]?.title ?? "a project"}.`, project.id);
    return { ok: true, invoiceId };
  });

export const markInvoiceSent = createServerFn({ method: "POST" })
  .validator((input: { invoiceId: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.invoiceId)) return fail("Unknown invoice.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Only the studio sends invoices.");
    const rows = await sql<{ status: string; number: string; project_id: string }>`
      select status, number, project_id from invoices
      where id = ${data.invoiceId} and studio_id = ${access.studioId} limit 1
    `;
    const row = rows[0];
    if (!row) return fail("That invoice is not in your studio.");
    if (row.status === "void") return fail("This invoice is void.");
    if (row.status === "draft") {
      await sql`update invoices set status = 'sent' where id = ${data.invoiceId}`;
      await logAct(sql, access.studioId, access.userId, `Invoice ${row.number} marked sent.`, row.project_id);
    }
    return { ok: true };
  });

export const voidInvoice = createServerFn({ method: "POST" })
  .validator((input: { invoiceId: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.invoiceId)) return fail("Unknown invoice.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role !== "owner") return fail("Only the owner can void an invoice.");
    const rows = await sql<{ number: string; project_id: string }>`
      select number, project_id from invoices where id = ${data.invoiceId} and studio_id = ${access.studioId} limit 1
    `;
    if (!rows[0]) return fail("That invoice is not in your studio.");
    await sql`update invoices set status = 'void' where id = ${data.invoiceId}`;
    await logAct(sql, access.studioId, access.userId, `Invoice ${rows[0].number} voided.`, rows[0].project_id);
    return { ok: true };
  });

export const recordPayment = createServerFn({ method: "POST" })
  .validator((input: { invoiceId: string; amountCents: number; method: string; reference: string; paidOn: string; pending: boolean }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.invoiceId)) return fail("Unknown invoice.");
    const amount = Math.round(num(data.amountCents));
    if (amount < 100) return fail("Enter at least R1.");
    const method = text(data.method, 20);
    if (!["eft", "cash", "card", "payfast"].includes(method)) return fail("Choose how it was paid.");
    const paidOn = text(data.paidOn, 10);
    if (!dayOk(paidOn)) return fail("Pick the day it was paid.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    const invoices = await invoiceRows(sql, access.studioId, {
      clientId: access.role === "client" ? access.clientId : null,
    });
    const invoice = invoices.find((item) => item.id === data.invoiceId);
    if (!invoice || invoice.status === "void") return fail("That invoice is not open.");
    const pending = access.role === "client" ? true : Boolean(data.pending);
    const room = invoice.balanceCents - (pending ? invoice.pendingCents : 0);
    if (invoice.balanceCents <= 0) return fail("This invoice is already paid in full.");
    if (amount > room) return fail("That is more than the balance still open.");
    await sql`
      insert into payments (id, invoice_id, studio_id, amount_cents, method, reference, status, paid_on, recorded_by)
      values (
        ${crypto.randomUUID()}, ${invoice.id}, ${access.studioId}, ${amount}, ${method},
        ${text(data.reference, 80)}, ${pending ? "pending" : "confirmed"}, ${paidOn}, ${access.userId}
      )
    `;
    if (!pending) {
      await recomputeInvoice(sql, invoice.id);
      await maybeAdvance(sql, invoice.projectId, access.userId, access.studioId);
      await logAct(
        sql,
        access.studioId,
        access.userId,
        `Payment recorded on ${invoice.number} for ${invoice.clientName}.`,
        invoice.projectId,
      );
    } else {
      await logAct(
        sql,
        access.studioId,
        access.userId,
        `${access.name} says they paid ${invoice.number}. Confirm it in the studio.`,
        invoice.projectId,
      );
    }
    return { ok: true };
  });

export const resolvePayment = createServerFn({ method: "POST" })
  .validator((input: { paymentId: string; decision: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.paymentId)) return fail("Unknown payment.");
    const decision = text(data.decision, 20);
    if (decision !== "confirm" && decision !== "reject") return fail("Choose confirm or reject.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Only the studio confirms payments.");
    const rows = await sql<{ invoice_id: string }>`
      select invoice_id from payments
      where id = ${data.paymentId} and studio_id = ${access.studioId} and status = 'pending' limit 1
    `;
    const row = rows[0];
    if (!row) return fail("That notice is already handled.");
    await sql`
      update payments set status = ${decision === "confirm" ? "confirmed" : "rejected"}
      where id = ${data.paymentId}
    `;
    await recomputeInvoice(sql, row.invoice_id);
    if (decision === "confirm") {
      const project = await sql<{ project_id: string }>`select project_id from invoices where id = ${row.invoice_id}`;
      if (project[0]) await maybeAdvance(sql, project[0].project_id, access.userId, access.studioId);
    }
    return { ok: true };
  });

export const inviteMember = createServerFn({ method: "POST" })
  .validator((input: { name: string; email: string; title: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    const name = text(data.name, 120);
    const email = text(data.email, 160).toLowerCase();
    const title = text(data.title, 80) || "Teammate";
    if (!name) return fail("Add their name.");
    if (!emailOk(email)) return fail("Add the email they will sign in with.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role !== "owner") return fail("Only the owner invites the team.");
    const clash = await sql<{ id: string }>`
      select id from members where studio_id = ${access.studioId} and lower(email) = lower(${email}) limit 1
    `;
    if (clash.length) return fail("That email is already on the studio.");
    await sql`
      insert into members (id, studio_id, user_id, client_id, email, name, role, title)
      values (${crypto.randomUUID()}, ${access.studioId}, null, null, ${email}, ${name}, 'teammate', ${title})
    `;
    await logAct(sql, access.studioId, access.userId, `${name} was invited to the studio.`, null);
    return { ok: true };
  });

export const removeMember = createServerFn({ method: "POST" })
  .validator((input: { memberId: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.memberId)) return fail("Unknown teammate.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role !== "owner") return fail("Only the owner removes teammates.");
    const rows = await sql<{ role: string; name: string }>`
      select role, name from members where id = ${data.memberId} and studio_id = ${access.studioId} limit 1
    `;
    const row = rows[0];
    if (!row || row.role === "owner" || row.role === "client") return fail("That person stays.");
    await sql`delete from members where id = ${data.memberId}`;
    await logAct(sql, access.studioId, access.userId, `${row.name} was removed from the team.`, null);
    return { ok: true };
  });

export const updateStudio = createServerFn({ method: "POST" })
  .validator((input: StudioInfo) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role !== "owner") return fail("Only the owner edits studio details.");
    await sql`
      update studios set
        phone = ${text(data.phone, 40)},
        whatsapp = ${text(data.whatsapp, 40)},
        location = ${text(data.location, 120)},
        bank_name = ${text(data.bankName, 80)},
        bank_account = ${text(data.bankAccount, 40)},
        bank_holder = ${text(data.bankHolder, 120)},
        bank_branch = ${text(data.bankBranch, 40)},
        tagline = ${text(data.tagline, 160)}
      where id = ${access.studioId}
    `;
    return { ok: true };
  });

export const updateClient = createServerFn({ method: "POST" })
  .validator((input: { clientId: string; businessName: string; contactName: string; phone: string; email: string; whatsapp: string; location: string; notes: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Result> => {
    if (!idOk(data.clientId)) return fail("Unknown customer.");
    const business = text(data.businessName, 120);
    const contact = text(data.contactName, 120);
    const email = text(data.email, 160).toLowerCase();
    if (!business || !contact) return fail("Business and contact name are required.");
    if (email && !emailOk(email)) return fail("That email does not look right.");
    const sql = await getSql();
    const access = await ensureAccess(sql, context.userId);
    if (access.role === "client") return fail("Only the studio edits customer records.");
    const rows = await sql<{ id: string }>`
      select id from clients where id = ${data.clientId} and studio_id = ${access.studioId} limit 1
    `;
    if (!rows[0]) return fail("That customer is not in your studio.");
    await sql`
      update clients set
        business_name = ${business},
        contact_name = ${contact},
        phone = ${text(data.phone, 40)},
        email = ${email},
        whatsapp = ${text(data.whatsapp, 40)},
        location = ${text(data.location, 120)},
        notes = ${block(data.notes, 2000)}
      where id = ${data.clientId}
    `;
    await syncClientMember(sql, access.studioId, data.clientId, email, contact);
    return { ok: true };
  });
