import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useStudio } from "@/components/shell";
import { Card, EmptyState, InvoiceBadge } from "@/components/ui";
import { formatDay, formatZar } from "@/lib/studio-shared";

export const Route = createFileRoute("/app/invoices/")({ component: InvoicesPage });

const filters = [
  { id: "open", label: "Balance due" },
  { id: "paid", label: "Paid" },
  { id: "draft", label: "Drafts" },
  { id: "all", label: "All" },
] as const;

function InvoicesPage() {
  const { invoices, role } = useStudio();
  const [filter, setFilter] = useState<(typeof filters)[number]["id"]>("open");
  const visible = invoices.filter((invoice) => {
    if (filter === "all") return true;
    if (filter === "paid") return invoice.status === "paid";
    if (filter === "draft") return invoice.status === "draft";
    return invoice.status !== "void" && invoice.status !== "paid" && invoice.balanceCents > 0;
  });
  const due = invoices
    .filter((invoice) => invoice.status !== "void" && invoice.status !== "paid")
    .reduce((sum, invoice) => sum + invoice.balanceCents, 0);
  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl font-semibold">Invoices</h1>
        <p className="mt-1 text-muted tabular-nums">
          {role === "client" ? "What you owe" : "Still to collect"}: {formatZar(due)}
        </p>
      </div>
      <div className="flex gap-2 overflow-x-auto">
        {filters.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`min-h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${filter === item.id ? "bg-navy text-paper" : "bg-card text-navy shadow-card"}`}
            onClick={() => setFilter(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>
      {visible.length === 0 ? (
        <EmptyState title="No invoices here" body="Paid work and open balances show up once a quote is on a job." />
      ) : (
        <div className="space-y-3">
          {visible.map((invoice) => (
            <Link key={invoice.id} to="/app/invoices/$invoiceId" params={{ invoiceId: invoice.id }} className="block">
              <Card>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-display text-lg font-semibold">{invoice.clientName}</p>
                    <p className="text-sm text-muted">
                      {invoice.number}
                      {invoice.dueOn ? ` · due ${formatDay(invoice.dueOn)}` : ""}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-xl font-semibold tabular-nums">{formatZar(invoice.balanceCents)}</p>
                    <InvoiceBadge status={invoice.status} dueOn={invoice.dueOn} />
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
