import { createFileRoute } from "@tanstack/react-router";
import { InvoiceScreen } from "@/components/invoice-screen";

export const Route = createFileRoute("/app/invoices/$invoiceId")({
  component: InvoiceRoute,
});

function InvoiceRoute() {
  const { invoiceId } = Route.useParams();
  return <InvoiceScreen invoiceId={invoiceId} />;
}
