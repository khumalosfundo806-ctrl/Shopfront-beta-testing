import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { useStudio } from "@/components/shell";
import { Button, Card, EmptyState, Field, fieldClass } from "@/components/ui";
import { inviteMember, removeMember } from "@/lib/studio.functions";
import { formatMinutes } from "@/lib/studio-shared";

export const Route = createFileRoute("/app/team")({ component: TeamPage });

function TeamPage() {
  const { role, realRole, ws, run } = useStudio();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [title, setTitle] = useState("Design");
  const [pendingRemove, setPendingRemove] = useState<string | null>(null);
  if (role === "client") {
    return <EmptyState title="The team stays backstage" body="You’ll see notes they share on your project." />;
  }
  const hours = new Map<string, number>();
  for (const entry of ws.timeEntries) {
    hours.set(entry.memberName, (hours.get(entry.memberName) ?? 0) + entry.minutes);
  }
  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl font-semibold">Team</h1>
        <p className="mt-2 max-w-xl text-muted">
          People you hire sign in with the email you add here. They share the same projects, time log and notes.
        </p>
      </div>
      <div className="grid gap-3">
        {ws.team.map((member) => (
          <Card key={member.id}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-display text-xl font-semibold">{member.name}</p>
                <p className="text-sm text-muted">
                  {member.title || member.role} · {member.linked ? "Signed in" : member.email ? `Waiting on ${member.email}` : "No email yet"}
                </p>
                <p className="mt-1 text-sm tabular-nums">{formatMinutes(hours.get(member.name) ?? 0)} logged</p>
              </div>
              {realRole === "owner" && member.role === "teammate" ? (
                pendingRemove === member.id ? (
                  <Button
                    variant="line"
                    onClick={() =>
                      void run(() => removeMember({ data: { memberId: member.id } })).then((result) => {
                        if (result.ok) setPendingRemove(null);
                      })
                    }
                  >
                    Remove {member.name.split(" ")[0]}
                  </Button>
                ) : (
                  <Button variant="line" onClick={() => setPendingRemove(member.id)}>
                    Remove
                  </Button>
                )
              ) : null}
            </div>
          </Card>
        ))}
      </div>
      {realRole === "owner" ? (
        <Card>
          <h2 className="font-display text-xl font-semibold">Invite someone</h2>
          <form
            className="mt-3 grid gap-3 sm:grid-cols-2"
            onSubmit={(event) => {
              event.preventDefault();
              void run(() => inviteMember({ data: { name, email, title } })).then((result) => {
                if (result.ok) {
                  toast.success("They’re on the team once they sign in.");
                  setName("");
                  setEmail("");
                }
              });
            }}
          >
            <Field label="Name">
              <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
            </Field>
            <Field label="Email they will sign in with">
              <input className={fieldClass} type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
            </Field>
            <Field label="Role on jobs">
              <input className={fieldClass} value={title} onChange={(event) => setTitle(event.target.value)} />
            </Field>
            <div className="flex items-end">
              <Button type="submit">Invite</Button>
            </div>
          </form>
        </Card>
      ) : (
        <p className="text-sm text-muted">The owner invites new people.</p>
      )}
    </div>
  );
}
