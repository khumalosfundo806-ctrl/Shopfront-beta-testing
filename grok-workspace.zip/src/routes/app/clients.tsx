import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { useStudio } from "@/components/shell";
import { Button, Card, EmptyState, Field, fieldClass } from "@/components/ui";
import { updateClient } from "@/lib/studio.functions";
import { formatZar, waDigits, type ClientCard } from "@/lib/studio-shared";

export const Route = createFileRoute("/app/clients")({ component: ClientsPage });

function ClientsPage() {
  const { role, clients, projects, invoices } = useStudio();
  const [query, setQuery] = useState("");
  if (role === "client") {
    return <EmptyState title="This page is for the studio" body="Your own project is under My website." />;
  }
  const filtered = clients.filter((client) =>
    `${client.businessName} ${client.contactName}`.toLowerCase().includes(query.trim().toLowerCase()),
  );
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold">Customers</h1>
          <p className="mt-1 text-muted tabular-nums">{clients.length} on the books.</p>
        </div>
        <Link to="/app/book">
          <Button variant="gold">Add a customer</Button>
        </Link>
      </div>
      <input className={fieldClass} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search customers" aria-label="Search customers" />
      <div className="grid gap-3">
        {filtered.map((client) => (
          <ClientRow
            key={client.id}
            client={client}
            projectCount={projects.filter((project) => project.clientId === client.id).length}
            balance={invoices
              .filter((invoice) => invoice.clientId === client.id && invoice.status !== "void" && invoice.status !== "paid")
              .reduce((sum, invoice) => sum + invoice.balanceCents, 0)}
          />
        ))}
      </div>
    </div>
  );
}

function ClientRow({ client, projectCount, balance }: { client: ClientCard; projectCount: number; balance: number }) {
  const { projects, run } = useStudio();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(client);
  const digits = waDigits(client.whatsapp || client.phone);
  const latest = projects.find((project) => project.clientId === client.id);
  if (editing) {
    return (
      <Card>
        <form
          className="grid gap-3 sm:grid-cols-2"
          onSubmit={(event) => {
            event.preventDefault();
            void run(() =>
              updateClient({
                data: {
                  clientId: client.id,
                  businessName: form.businessName,
                  contactName: form.contactName,
                  phone: form.phone,
                  email: form.email,
                  whatsapp: form.whatsapp,
                  location: form.location,
                  notes: form.notes,
                },
              }),
            ).then((result) => {
              if (result.ok) {
                toast.success("Customer saved.");
                setEditing(false);
              }
            });
          }}
        >
          <Field label="Business">
            <input className={fieldClass} value={form.businessName} onChange={(event) => setForm({ ...form, businessName: event.target.value })} />
          </Field>
          <Field label="Contact">
            <input className={fieldClass} value={form.contactName} onChange={(event) => setForm({ ...form, contactName: event.target.value })} />
          </Field>
          <Field label="Phone">
            <input className={fieldClass} value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} />
          </Field>
          <Field label="WhatsApp">
            <input className={fieldClass} value={form.whatsapp} onChange={(event) => setForm({ ...form, whatsapp: event.target.value })} />
          </Field>
          <Field label="Email">
            <input className={fieldClass} value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} />
          </Field>
          <Field label="Area">
            <input className={fieldClass} value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value })} />
          </Field>
          <Field label="Notes">
            <textarea className={`${fieldClass} min-h-20 py-2 sm:col-span-2`} value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
          </Field>
          <div className="flex gap-2 sm:col-span-2">
            <Button type="submit">Save</Button>
            <Button variant="line" onClick={() => setEditing(false)}>
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    );
  }
  return (
    <Card>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-semibold">{client.businessName}</h2>
          <p className="text-sm text-muted">
            {client.contactName}
            {client.location ? ` · ${client.location}` : ""}
          </p>
          <p className="mt-2 text-sm">
            {projectCount} {projectCount === 1 ? "project" : "projects"} · {balance ? `${formatZar(balance)} due` : "Nothing owing"}
          </p>
          <p className="mt-1 text-sm text-muted">{client.signedIn ? "Signed in to the portal" : client.email ? `Portal opens when they sign in as ${client.email}` : "Add an email so they can sign in"}</p>
          {client.notes ? <p className="mt-2 text-sm">{client.notes}</p> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          {latest ? (
            <Link to="/app/projects/$projectId" params={{ projectId: latest.id }}>
              <Button>Open job</Button>
            </Link>
          ) : null}
          {digits ? (
            <a href={`https://wa.me/${digits}`} target="_blank" rel="noreferrer">
              <Button variant="whatsapp">WhatsApp</Button>
            </a>
          ) : null}
          <Button variant="line" onClick={() => setEditing(true)}>
            Edit
          </Button>
        </div>
      </div>
    </Card>
  );
}
