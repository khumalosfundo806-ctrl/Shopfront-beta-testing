import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { useStudio } from "@/components/shell";
import { Button, Card, EmptyState, Field, fieldClass } from "@/components/ui";
import { deleteTime, logTime, stopTimer } from "@/lib/studio.functions";
import { formatDay, formatMinutes, last7Days, todayKey } from "@/lib/studio-shared";
import { toast } from "sonner";

export const Route = createFileRoute("/app/time")({ component: TimePage });

function TimePage() {
  const { role, ws, projects, run } = useStudio();
  const [projectId, setProjectId] = useState(projects[0]?.id ?? "");
  const [hours, setHours] = useState("1");
  const [mins, setMins] = useState("0");
  const [note, setNote] = useState("");
  const [workedOn, setWorkedOn] = useState(todayKey());
  const [memberName, setMemberName] = useState(ws.me.name);
  if (role === "client") {
    return <EmptyState title="Time stays with the studio" body="You can see how long your own site has taken on the project page." />;
  }
  const week = last7Days(ws.timeEntries);
  const weekMinutes = week.reduce((sum, day) => sum + day.minutes, 0);
  const allMinutes = ws.timeEntries.reduce((sum, entry) => sum + entry.minutes, 0);
  const byPerson = new Map<string, number>();
  for (const entry of ws.timeEntries) byPerson.set(entry.memberName, (byPerson.get(entry.memberName) ?? 0) + entry.minutes);
  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl font-semibold">Time</h1>
        <p className="mt-1 text-muted tabular-nums">
          {formatMinutes(weekMinutes)} in the last 7 days · {formatMinutes(allMinutes)} all time
        </p>
      </div>
      <Card>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={week.map((day) => ({ label: day.label, hours: Math.round((day.minutes / 60) * 10) / 10 }))}>
              <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
              <Tooltip cursor={{ fill: "var(--color-gold-soft)" }} />
              <Bar dataKey="hours" fill="var(--color-navy)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <div className="grid gap-3 sm:grid-cols-3">
        {[...byPerson.entries()].map(([name, minutes]) => (
          <Card key={name}>
            <p className="text-sm text-muted">{name}</p>
            <p className="font-display text-2xl font-semibold tabular-nums">{formatMinutes(minutes)}</p>
          </Card>
        ))}
      </div>
      <Card>
        <h2 className="font-display text-xl font-semibold">Log time</h2>
        {ws.timer ? (
          <p className="mt-2 text-sm">
            Timer running on {ws.timer.projectTitle}.{" "}
            <button
              type="button"
              className="font-semibold text-gold-deep"
              onClick={() =>
                void run(() => stopTimer()).then((result) => {
                  if (result.ok && "minutes" in result) toast.success(`Logged ${formatMinutes(result.minutes)}`);
                })
              }
            >
              Stop and save
            </button>
          </p>
        ) : null}
        <form
          className="mt-3 grid gap-3 sm:grid-cols-2"
          onSubmit={(event) => {
            event.preventDefault();
            const minutes = Math.round(Number(hours || 0) * 60 + Number(mins || 0));
            void run(() => logTime({ data: { projectId, minutes, note, workedOn, memberName } })).then((result) => {
              if (result.ok) setNote("");
            });
          }}
        >
          <Field label="Project">
            <select className={fieldClass} value={projectId} onChange={(event) => setProjectId(event.target.value)}>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.clientName}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Who">
            <input className={fieldClass} value={memberName} onChange={(event) => setMemberName(event.target.value)} />
          </Field>
          <Field label="Hours">
            <input className={fieldClass} inputMode="numeric" value={hours} onChange={(event) => setHours(event.target.value)} />
          </Field>
          <Field label="Minutes">
            <input className={fieldClass} inputMode="numeric" value={mins} onChange={(event) => setMins(event.target.value)} />
          </Field>
          <Field label="Day">
            <input className={fieldClass} type="date" value={workedOn} onChange={(event) => setWorkedOn(event.target.value)} />
          </Field>
          <Field label="Note">
            <input className={fieldClass} value={note} onChange={(event) => setNote(event.target.value)} />
          </Field>
          <div className="sm:col-span-2">
            <Button type="submit">Add to the log</Button>
          </div>
        </form>
      </Card>
      <Card>
        <h2 className="font-display text-xl font-semibold">Entries</h2>
        <ul className="mt-2 divide-y divide-line">
          {ws.timeEntries.map((entry) => (
            <li key={entry.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <Link to="/app/projects/$projectId" params={{ projectId: entry.projectId }} className="font-semibold">
                  {entry.projectTitle}
                </Link>
                <p className="text-sm text-muted">
                  {entry.memberName} · {formatDay(entry.workedOn)}
                  {entry.note ? ` · ${entry.note}` : ""}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold tabular-nums">{formatMinutes(entry.minutes)}</span>
                <button type="button" className="text-sm text-muted" onClick={() => void run(() => deleteTime({ data: { entryId: entry.id } }))}>
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
