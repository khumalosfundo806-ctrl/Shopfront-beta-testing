import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { useStudio } from "@/components/shell";
import { Button, Card, EmptyState, Field, fieldClass } from "@/components/ui";
import { updateStudio } from "@/lib/studio.functions";

export const Route = createFileRoute("/app/settings")({ component: SettingsPage });

function SettingsPage() {
  const { role, realRole, ws, run } = useStudio();
  const [form, setForm] = useState(ws.studio);
  if (role === "client") {
    return <EmptyState title="Studio settings stay private" body="Payment details appear on your invoice when you are ready to pay." />;
  }
  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div>
        <h1 className="font-display text-3xl font-semibold">Studio settings</h1>
        <p className="mt-2 text-muted">These details print on invoices and open WhatsApp.</p>
      </div>
      <Card>
        <form
          className="space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            if (realRole !== "owner") {
              toast.error("Only the owner edits these.");
              return;
            }
            void run(() => updateStudio({ data: form })).then((result) => {
              if (result.ok) toast.success("Studio details saved.");
            });
          }}
        >
          <Field label="Tagline">
            <input className={fieldClass} value={form.tagline} onChange={(event) => set("tagline", event.target.value)} disabled={realRole !== "owner"} />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Phone">
              <input className={fieldClass} value={form.phone} onChange={(event) => set("phone", event.target.value)} disabled={realRole !== "owner"} />
            </Field>
            <Field label="WhatsApp number">
              <input className={fieldClass} value={form.whatsapp} onChange={(event) => set("whatsapp", event.target.value)} disabled={realRole !== "owner"} />
            </Field>
          </div>
          <Field label="Where you work from">
            <input className={fieldClass} value={form.location} onChange={(event) => set("location", event.target.value)} disabled={realRole !== "owner"} />
          </Field>
          <Field label="Bank">
            <input className={fieldClass} value={form.bankName} onChange={(event) => set("bankName", event.target.value)} disabled={realRole !== "owner"} />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Account number" hint="Customers see this on invoices.">
              <input className={fieldClass} value={form.bankAccount} onChange={(event) => set("bankAccount", event.target.value)} disabled={realRole !== "owner"} />
            </Field>
            <Field label="Branch code">
              <input className={fieldClass} value={form.bankBranch} onChange={(event) => set("bankBranch", event.target.value)} disabled={realRole !== "owner"} />
            </Field>
          </div>
          <Field label="Account holder">
            <input className={fieldClass} value={form.bankHolder} onChange={(event) => set("bankHolder", event.target.value)} disabled={realRole !== "owner"} />
          </Field>
          {realRole === "owner" ? <Button type="submit">Save settings</Button> : <p className="text-sm text-muted">Only the owner can change these.</p>}
        </form>
      </Card>
    </div>
  );
}
