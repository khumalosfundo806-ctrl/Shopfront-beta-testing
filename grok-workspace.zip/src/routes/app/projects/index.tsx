import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ProjectLink } from "@/components/bits";
import { useStudio } from "@/components/shell";
import { Button, EmptyState, fieldClass } from "@/components/ui";
import { STAGES } from "@/lib/studio-shared";

export const Route = createFileRoute("/app/projects/")({ component: ProjectsPage });

function ProjectsPage() {
  const { projects, role } = useStudio();
  const [stage, setStage] = useState("all");
  const [query, setQuery] = useState("");
  const filtered = projects.filter((project) => {
    const matchesStage = stage === "all" || project.stage === stage;
    const haystack = `${project.clientName} ${project.title} ${project.summary}`.toLowerCase();
    return matchesStage && haystack.includes(query.trim().toLowerCase());
  });
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold">{role === "client" ? "Your projects" : "Projects"}</h1>
          <p className="mt-1 text-muted">{projects.length} on the desk.</p>
        </div>
        <Link to="/app/book">
          <Button variant="gold">{role === "client" ? "Book another" : "New booking"}</Button>
        </Link>
      </div>
      <input
        className={fieldClass}
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search by business"
        aria-label="Search projects"
      />
      <div className="flex gap-2 overflow-x-auto pb-1">
        <Chip active={stage === "all"} onClick={() => setStage("all")}>
          All
        </Chip>
        {STAGES.map((item) => (
          <Chip key={item.id} active={stage === item.id} onClick={() => setStage(item.id)}>
            {item.short}
          </Chip>
        ))}
      </div>
      {filtered.length === 0 ? (
        <EmptyState title="Nothing in this lane" body="Try another stage, or book a new website." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((project) => (
            <ProjectLink key={project.id} project={project} />
          ))}
        </div>
      )}
    </div>
  );
}

function Chip({ active, children, onClick }: { active: boolean; children: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${active ? "bg-navy text-paper" : "bg-card text-navy shadow-card"}`}
    >
      {children}
    </button>
  );
}
