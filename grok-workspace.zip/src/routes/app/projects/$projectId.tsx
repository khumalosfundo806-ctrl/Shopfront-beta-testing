import { createFileRoute } from "@tanstack/react-router";
import { ProjectScreen } from "@/components/project-screen";

export const Route = createFileRoute("/app/projects/$projectId")({
  component: ProjectRoute,
});

function ProjectRoute() {
  const { projectId } = Route.useParams();
  return <ProjectScreen projectId={projectId} />;
}
