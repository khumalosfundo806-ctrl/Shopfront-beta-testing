import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Shell, StudioProvider } from "@/components/shell";
import { Splash } from "@/components/splash";

export const Route = createFileRoute("/app")({ component: AppLayout });

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted || isPending) return <Splash />;
  if (!user) return <RedirectToSignIn />;
  return (
    <StudioProvider>
      <Shell />
    </StudioProvider>
  );
}
