import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useStudio } from "@/components/shell";
import { Button, Card, Field, fieldClass } from "@/components/ui";
import { createBooking } from "@/lib/studio.functions";
import { PACKAGES, formatZar, randsToCents } from "@/lib/studio-shared";

export const Route = createFileRoute("/app/book")({ component: BookPage });

function BookPage() {
  const { role, clients, previewClient, ws, run } = useStudio();
  const navigate = useNavigate();
  const locked = role === "client" ? (previewClient ?? clients[0] ?? null) : null;
  const [packageId, setPackageId] = useState("starter");
  const [businessName, setBusinessName] = useState(locked?.businessName ?? "");
  const [contactName, setContactName] = useState(locked?.contactName ?? "");
  const [phone, setPhone] = useState(locked?.phone ?? "");
  const [email, setEmail] = useState(locked?.email ?? "");
  const [whatsapp, setWhatsapp] = useState(locked?.whatsapp ?? "");
  const [location, setLocation] = useState(locked?.location ?? "");
  const [brief, setBrief] = useState("");
  const [quote, setQuote] = useState("");
  const selected = PACKAGES.find((item) => item.id === packageId) ?? PACKAGES[0];

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div>
        <h1 className="font-display text-3xl font-semibold">{role === "client" ? "Book a website" : "New booking"}</h1>
        <p className="mt-2 text-muted">
          {role === "client"
            ? "Tell us about the business. You’ll see the quote here before we start."
            : "Add a customer. If they later sign in with this email, they only see their own job."}
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {PACKAGES.map((pack) => (
          <button
            key={pack.id}
            type="button"
            aria-pressed={packageId === pack.id}
            onClick={() => setPackageId(pack.id)}
            className={`rounded-2xl p-4 text-left shadow-card ${packageId === pack.id ? "bg-navy text-paper" : "bg-card text-navy"}`}
          >
            <p className="font-display text-2xl font-semibold tabular-nums">{pack.priceCents ? formatZar(pack.priceCents) : "Quote"}</p>
            <p className="mt-1 font-semibold">{pack.name}</p>
            <p className={`mt-2 text-sm ${packageId === pack.id ? "text-paper/80" : "text-muted"}`}>{pack.blurb}</p>
          </button>
        ))}
      </div>
      <Card>
        <form
          className="space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            const quoteCents = selected.priceCents > 0 ? selected.priceCents : randsToCents(quote) ?? 0;
            if (selected.id === "premium" && quote.trim() && randsToCents(quote) == null) {
              toast.error("Enter the premium quote in rands, or leave it blank.");
              return;
            }
            void run(() =>
              createBooking({
                data: {
                  businessName,
                  contactName,
                  phone,
                  email,
                  whatsapp,
                  location,
                  packageId,
                  brief,
                  quoteCents,
                },
              }),
            ).then((result) => {
              if (result.ok && "projectId" in result) {
                toast.success("Booking is on the desk.");
                void navigate({ to: "/app/projects/$projectId", params: { projectId: result.projectId } });
              }
            });
          }}
        >
          <Field label="Business">
            <input className={fieldClass} value={businessName} onChange={(event) => setBusinessName(event.target.value)} required />
          </Field>
          <Field label="Contact">
            <input className={fieldClass} value={contactName} onChange={(event) => setContactName(event.target.value)} required />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Phone">
              <input className={fieldClass} value={phone} onChange={(event) => setPhone(event.target.value)} />
            </Field>
            <Field label="WhatsApp">
              <input className={fieldClass} value={whatsapp} onChange={(event) => setWhatsapp(event.target.value)} placeholder="083…" />
            </Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Email" hint="They sign in with this to follow the job.">
              <input className={fieldClass} type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
            </Field>
            <Field label="Area">
              <input className={fieldClass} value={location} onChange={(event) => setLocation(event.target.value)} placeholder="KwaMashu" />
            </Field>
          </div>
          {selected.id === "premium" ? (
            <Field label="Quote in rands" hint="Leave blank if you still need to price it.">
              <input className={fieldClass} inputMode="decimal" value={quote} onChange={(event) => setQuote(event.target.value)} />
            </Field>
          ) : null}
          <Field label="What should the site say?">
            <textarea
              className={`${fieldClass} min-h-28 py-2`}
              value={brief}
              onChange={(event) => setBrief(event.target.value)}
              placeholder="Services, prices, hours, and anything a customer searches for."
            />
          </Field>
          <Button type="submit" variant="gold">
            {role === "client" ? `Send to ${ws.studio.name}` : "Create the job"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
