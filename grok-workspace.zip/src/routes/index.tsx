import { useEffect, useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { BrandLockup, Mark } from "@/components/logo";
import { Splash } from "@/components/splash";
import { Button } from "@/components/ui";
import { PACKAGES, formatZar } from "@/lib/studio-shared";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted || isPending) return <Splash />;
  if (user) return <Navigate to="/app" />;
  return <Marketing />;
}

function Marketing() {
  return (
    <div className="min-h-screen bg-paper">
      <header className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4 sm:px-6">
        <BrandLockup />
        <a href="tel:+27836825921" className="hidden text-sm font-semibold sm:inline">
          083 682 5921
        </a>
        <Link to="/login" className="inline-flex min-h-11 items-center rounded-xl bg-navy px-4 text-sm font-semibold text-paper">
          Sign in
        </Link>
      </header>
      <main>
        <section className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-8 sm:px-6 lg:grid-cols-2 lg:py-16">
          <div>
            <p className="text-sm font-semibold text-gold-deep">Ntuzuma, Durban · websites for local businesses</p>
            <h1 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">
              Get found online.
            </h1>
            <p className="mt-4 max-w-xl text-lg text-muted">
              Book a website, send your photos and words, and watch the job move from quote to paid in full. You deal with the person who builds it.
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              {GROK_PROVIDERS.map((provider) => (
                <Button
                  key={provider.providerId}
                  variant={provider.providerId.includes("google") ? "gold" : "line"}
                  onClick={() => signIn(provider.providerId, { callbackURL: "/app/book" })}
                >
                  Book with {provider.label}
                </Button>
              ))}
            </div>
            <p className="mt-4 text-sm text-muted">WhatsApp is still the fastest hello: 083 682 5921.</p>
          </div>
          <div className="rounded-3xl bg-navy p-4 text-paper shadow-card sm:p-6">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm text-gold">A job, as the customer sees it</p>
              <span className="rounded-full bg-gold px-3 py-1 text-sm font-semibold text-navy">Review</span>
            </div>
            <p className="mt-4 font-display text-2xl font-semibold">Laundromat Spot</p>
            <p className="mt-2 text-sm text-paper/80">Check it on your phone. Balance due when you say it is right.</p>
            <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-navy-soft">
              <div className="h-full w-3/4 rounded-full bg-gold" />
            </div>
            <dl className="mt-5 grid grid-cols-3 gap-3 text-sm">
              <div>
                <dt className="text-paper/70">Quote</dt>
                <dd className="font-display text-xl font-semibold tabular-nums">R1 500</dd>
              </div>
              <div>
                <dt className="text-paper/70">Paid</dt>
                <dd className="font-display text-xl font-semibold tabular-nums">R750</dd>
              </div>
              <div>
                <dt className="text-paper/70">Balance</dt>
                <dd className="font-display text-xl font-semibold tabular-nums">R750</dd>
              </div>
            </dl>
          </div>
        </section>
        <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
          <h2 className="font-display text-2xl font-semibold">Clear prices. They do not change.</h2>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {PACKAGES.map((pack) => (
              <article key={pack.id} className="rounded-2xl bg-card p-5 shadow-card">
                <p className="font-display text-3xl font-semibold tabular-nums">
                  {pack.priceCents ? formatZar(pack.priceCents) : "Quote"}
                </p>
                <h3 className="mt-2 font-display text-xl font-semibold">{pack.name}</h3>
                <p className="mt-2 text-muted">{pack.blurb}</p>
                <p className="mt-3 text-sm">{pack.detail}</p>
              </article>
            ))}
          </div>
        </section>
        <section className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-2xl font-semibold">How a job moves</h2>
            <ol className="mt-4 space-y-3">
              {[
                "Tell us about the business. You get a quote the same day.",
                "Pay the deposit. Half starts a starter site.",
                "Send photos, prices, colours and the words.",
                "Review it on your phone, then pay the balance.",
              ].map((step, index) => (
                <li key={step} className="flex gap-3 rounded-2xl bg-card p-4 shadow-card">
                  <span className="font-display text-xl font-semibold text-gold-deep">{index + 1}</span>
                  <p>{step}</p>
                </li>
              ))}
            </ol>
          </div>
          <blockquote className="flex flex-col justify-between rounded-3xl bg-navy p-6 text-paper">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-paper">
            <Mark className="h-10 w-10" />
          </span>
            <p className="mt-6 font-display text-2xl font-semibold">
              “Customers don’t search for your slogan. They search for what they need, and either you show up or you don’t.”
            </p>
            <p className="mt-4 text-sm text-gold">S’fundo Khumalo, founder · Shopfront Digital</p>
          </blockquote>
        </section>
        <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
          <p className="text-sm text-muted">Sites already out in the world</p>
          <p className="mt-2 font-display text-2xl font-semibold">JK Plumbers · Laundromat Spot · Ethekwini Roofing</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href="https://wa.me/27836825921" target="_blank" rel="noreferrer">
              <Button variant="whatsapp">WhatsApp 083 682 5921</Button>
            </a>
            <a href="tel:+27836825921">
              <Button variant="line">Call</Button>
            </a>
          </div>
        </section>
      </main>
      <footer className="border-t border-line px-4 py-6 text-sm text-muted sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-wrap justify-between gap-2">
          <BrandLockup markClass="h-8 w-8" />
          <p>Ntuzuma, Durban. No account managers. No hidden fees.</p>
        </div>
      </footer>
    </div>
  );
}
