import { useEffect, useState } from "react";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Mark, Wordmark } from "@/components/logo";
import { Splash } from "@/components/splash";
import { Button } from "@/components/ui";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted || isPending) return <Splash label="Checking your sign-in" />;
  if (user) return <Navigate to="/app" />;
  return (
    <main className="grid min-h-screen place-items-center bg-paper px-6 py-16">
      <div className="w-full max-w-md">
        <Mark className="h-14 w-14" />
        <h1 className="mt-4 font-display text-3xl font-semibold">
          <Wordmark />
        </h1>
        <p className="mt-3 text-muted">Sign in to book a website, follow the build, or open the studio desk.</p>
        <div className="mt-6 flex flex-col gap-3">
          {GROK_PROVIDERS.map((provider) => (
            <Button
              key={provider.providerId}
              variant={provider.providerId.includes("google") ? "primary" : "line"}
              onClick={() => signIn(provider.providerId, { callbackURL: "/app" })}
            >
              Continue with {provider.label}
            </Button>
          ))}
        </div>
      </div>
    </main>
  );
}
