create table if not exists studios (
  id text primary key,
  name text not null,
  phone text not null default '',
  whatsapp text not null default '',
  location text not null default '',
  bank_name text not null default '',
  bank_account text not null default '',
  bank_holder text not null default '',
  bank_branch text not null default '',
  tagline text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists clients (
  id text primary key,
  studio_id text not null,
  user_id text,
  business_name text not null,
  contact_name text not null,
  phone text not null default '',
  email text not null default '',
  whatsapp text not null default '',
  location text not null default '',
  notes text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists clients_studio_idx on clients (studio_id);

create table if not exists members (
  id text primary key,
  studio_id text not null,
  user_id text,
  client_id text,
  email text not null default '',
  name text not null,
  role text not null,
  title text not null default '',
  created_at timestamptz not null default now()
);

create unique index if not exists members_user_uq on members (user_id) where user_id is not null;
create unique index if not exists members_one_owner on members (studio_id) where role = 'owner';
create index if not exists members_studio_idx on members (studio_id);

create table if not exists projects (
  id text primary key,
  studio_id text not null,
  client_id text not null,
  title text not null,
  package_id text not null,
  stage text not null,
  summary text not null default '',
  quote_cents integer not null default 0,
  lead_name text not null default '',
  due_on date,
  delivered_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists projects_studio_idx on projects (studio_id);
create index if not exists projects_client_idx on projects (client_id);

create table if not exists checklist_items (
  id text primary key,
  project_id text not null,
  studio_id text not null,
  label text not null,
  done boolean not null default false,
  sort integer not null default 0
);

create index if not exists checklist_project_idx on checklist_items (project_id);

create table if not exists assets (
  id text primary key,
  project_id text not null,
  studio_id text not null,
  kind text not null,
  title text not null,
  body text not null default '',
  url text not null default '',
  color text not null default '',
  created_by text not null,
  created_at timestamptz not null default now()
);

create index if not exists assets_project_idx on assets (project_id);

create table if not exists time_entries (
  id text primary key,
  project_id text not null,
  studio_id text not null,
  user_id text not null,
  member_name text not null,
  minutes integer not null,
  note text not null default '',
  worked_on date not null,
  created_at timestamptz not null default now()
);

create index if not exists time_studio_idx on time_entries (studio_id);

create table if not exists timers (
  user_id text primary key,
  studio_id text not null,
  project_id text not null,
  started_at timestamptz not null
);

create table if not exists invoices (
  id text primary key,
  studio_id text not null,
  project_id text not null,
  client_id text not null,
  number text not null,
  status text not null,
  issued_on date not null,
  due_on date,
  notes text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists invoices_studio_idx on invoices (studio_id);

create table if not exists invoice_lines (
  id text primary key,
  invoice_id text not null,
  description text not null,
  qty integer not null default 1,
  unit_cents integer not null,
  sort integer not null default 0
);

create index if not exists invoice_lines_invoice_idx on invoice_lines (invoice_id);

create table if not exists payments (
  id text primary key,
  invoice_id text not null,
  studio_id text not null,
  amount_cents integer not null,
  method text not null,
  reference text not null default '',
  status text not null,
  paid_on date not null,
  recorded_by text not null,
  created_at timestamptz not null default now()
);

create index if not exists payments_invoice_idx on payments (invoice_id);

create table if not exists comments (
  id text primary key,
  project_id text not null,
  studio_id text not null,
  user_id text not null,
  author_name text not null,
  author_role text not null,
  body text not null,
  visibility text not null,
  created_at timestamptz not null default now()
);

create index if not exists comments_project_idx on comments (project_id);

create table if not exists activity (
  id text primary key,
  studio_id text not null,
  project_id text,
  user_id text not null,
  message text not null,
  created_at timestamptz not null default now()
);

create index if not exists activity_studio_idx on activity (studio_id);
